﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;
using UnityEngine.SceneManagement;

public class VR_GameScene : MonoBehaviour
{
    private GameObject[] tagObjects;

    private SteamVR_Action_Boolean actionToHaptic = SteamVR_Actions._default.Menu;
    private SteamVR_Action_Vibration haptic = SteamVR_Actions._default.Haptic;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        tagObjects = GameObject.FindGameObjectsWithTag("Crystal");

        if(tagObjects.Length <= 0)
        {
            if (actionToHaptic.GetStateDown(SteamVR_Input_Sources.LeftHand))
            {
                SceneManager.LoadScene("result");
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            SceneManager.LoadScene("gameOver");
        }
    }
}
