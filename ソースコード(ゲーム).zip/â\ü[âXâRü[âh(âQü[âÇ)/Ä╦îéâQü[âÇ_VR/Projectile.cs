﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float m_LifeTime = 0.5f; //寿命
    private Rigidbody m_RigitBody = null;

    private void Awake()
    {
        m_RigitBody = GetComponent<Rigidbody>();
        SetInnactive();
    }

    private void OnCollisionEnter(Collision collision)
    {
        SetInnactive();
    }

    public void Launch(Blaster blaster)
    {
        //位置情報
        transform.position = blaster.m_Barrel.position;
        transform.rotation = blaster.m_Barrel.rotation;

        //アクティブ
        gameObject.SetActive(true);

        //発射
        m_RigitBody.AddRelativeForce(Vector3.forward * blaster.m_Force , ForceMode.Impulse);
        StartCoroutine(TrackLifeLimit());
    }

    private IEnumerator TrackLifeLimit()
    {
        yield return new WaitForSeconds(m_LifeTime);
        SetInnactive();
    }

    public void SetInnactive()
    {
        m_RigitBody.velocity = Vector3.zero;
        m_RigitBody.angularVelocity = Vector3.zero;

        gameObject.SetActive(false);
    }
}
