﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//発射体の作成クラス
public class Pool
{
    //tはタイプの略
    //ジェネリック関数
    public List<T> Create<T>(GameObject prefub , int count)
        where T : MonoBehaviour //タイプの定義
    {
        //リスト作成
        List<T> newPool = new List<T>();

        for(int i = 0 ; i < count ; i++ )
        {
            GameObject projectileObject = GameObject.Instantiate(prefub, Vector3.zero, Quaternion.identity);
            T newProjectile = projectileObject.GetComponent<T>();
            newPool.Add(newProjectile);

        }

        return newPool;
    }
}

public class ProjectilePool : Pool
{
    public List<Projectile> m_Projectles = new List<Projectile>();

    public ProjectilePool(GameObject prefab, int count)
    {
        m_Projectles = Create<Projectile>(prefab , count);
    }

    //リロードの際に使用するセット関数
    public void SetAllProjectile()
    {
        foreach (Projectile projectile in m_Projectles)
            projectile.SetInnactive();
    }
}
