﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeActive : MonoBehaviour
{
    public GameObject[] m_TargetObjects;
    public bool m_TimeOnActive = true;
    public float m_TimeInterval = 0f;

    private float m_Time = 0f;

    private void Awake()
    {
        if (m_TimeOnActive == true)
        {
            for (int i = 0; i < m_TargetObjects.Length; i++)
            {
                m_TargetObjects[i].SetActive(false);
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        TimeOnActive();
    }

    //時間制限付きポーズ機能
    private void TimePause()
    {

    }

    private void TimeOnActive()
    {
        //時間が来るまで、オブジェクトを非アクティブにする。
        if (m_Time < m_TimeInterval)
        {
            m_Time += Time.deltaTime;
        }
        else
        {
            for (int i = 0; i < m_TargetObjects.Length; i++)
            {
                m_TargetObjects[i].SetActive(true);
            }
        }
    }
}
