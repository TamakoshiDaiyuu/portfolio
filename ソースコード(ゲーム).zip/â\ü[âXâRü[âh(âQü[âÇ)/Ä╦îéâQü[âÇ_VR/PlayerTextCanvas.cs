﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;
using UnityEngine.SceneManagement;

public class PlayerTextCanvas : MonoBehaviour
{
    private GameObject[] m_Targets;
    private GameObject m_Blaster;

    public float m_CTTimeInterval = 0f;
    private float m_CTTime = 0f;

    private float m_GameTime = 30f;
    private float m_RTTime = 0f;

    private Text m_Text;

    private int m_DestroyCount = 0;
    private float m_ShotCount = 0;
    private bool m_bCount = false;

    public SteamVR_Action_Boolean m_MoveScene = null;

    // Start is called before the first frame update
    void Start()
    {
        m_CTTime = m_CTTimeInterval;
        m_RTTime = m_GameTime;
        m_Text = this.transform.GetChild(1).GetComponent<Text>();
        this.transform.GetChild(0).gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        CountText();
        ResultText();
    }

    private void CountText()
    {
        if (m_CTTime > 0)
        {
            m_CTTime -= Time.deltaTime;
            m_Text.text = "ゲーム開始";
            m_Text.text += "\n" + m_CTTime.ToString("f1");
        }
        else
        {
            this.transform.GetChild(1).gameObject.SetActive(false);
        }
    }

    private void ResultText()
    {
        if(m_RTTime > 0)
        {
            if(this.transform.GetChild(1).gameObject.active == false)
            {
                m_RTTime -= Time.deltaTime;
            }
        }
        else
        {
            ResultPreference();
            m_Text = this.transform.GetChild(0).GetComponent<Text>();

            m_Text.text = "撃破した数";
            m_Text.text += "\n" + m_DestroyCount;
            m_Text.text += "\n" + "命中率";
            m_Text.text += "\n" + m_ShotCount;

            this.transform.GetChild(0).gameObject.SetActive(true);

            StartCoroutine(MoveScene());            
        }
    }
    private void ResultPreference()
    {
        if (this.gameObject.active == true && m_bCount == false)
        {
            m_Targets = GameObject.FindGameObjectsWithTag("Target");
            for (int i = 0; i < m_Targets.Length; i++)
            {
                m_DestroyCount += m_Targets[i].transform.GetComponent<Target>().GetDestroyCount();
            }
            m_Blaster = GameObject.FindGameObjectWithTag("Gun");
            m_ShotCount = m_Blaster.transform.GetComponent<Blaster>().GetShotCount();
            m_ShotCount = m_DestroyCount / m_ShotCount * 100;
            m_bCount = true;
        }
    }

    private IEnumerator MoveScene()
    {
        yield return new WaitForSeconds(7.0f);
        SceneManager.LoadScene("Title");
    }
}
