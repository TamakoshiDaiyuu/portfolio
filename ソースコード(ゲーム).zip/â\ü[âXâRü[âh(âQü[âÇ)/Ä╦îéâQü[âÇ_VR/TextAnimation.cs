﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextAnimation : MonoBehaviour
{
    private Vector3 m_OriginalText;

    public float m_TimeInterval = 0f;
    private float m_Time = 0f;

    public float m_ScaleValue;
    private Vector3 m_scale = new Vector3(0f, 0f, 0f);
    private Vector3 m_OriginalScale = new Vector3(1f, 1f, 1f);

    // Start is called before the first frame update
    void Start()
    {
        m_OriginalScale = this.transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        AppearScale();
    }

    private void AppearScale()
    {
        //待ち時間の設定
        if(m_Time > m_TimeInterval)
        {
            if (m_scale.x < m_OriginalScale.x && m_scale.y < m_OriginalScale.y)
            {
                m_scale.x += m_ScaleValue;
                m_scale.y += m_ScaleValue;
            }
        }
        else
        {
            m_Time += Time.deltaTime;
        }

        this.transform.localScale = new Vector3(m_scale.x , m_scale.y , m_scale.z);
    }
}
