//-----------------------------------------------------------------
//GM31 renderer
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------
//-----------------------------------------------------------------
//�C���N���[�h�K�[�h
//-----------------------------------------------------------------
#ifndef _CPLAYER_H_
#define _CPLAYER_H_

//-------------------------------------------------------------------
//�C���N���[�h
//-------------------------------------------------------------------
#include "d3dx9.h"
#include "scene.h"
#include "alut.h"
//-------------------------------------------------------------------
//���C�u�����̃����N
//-------------------------------------------------------------------
#pragma comment(lib,"OpenAL32.lib")
#pragma comment(lib,"alut.lib")

//-------------------------------------------------------------------
//�}�N����`
//-------------------------------------------------------------------
#define MAX_BREADCRUM ( 5 )
//-------------------------------------------------------------------
//�\����
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�N���X
//-------------------------------------------------------------------
class CPlayer : public CScene
{
	private:

		int m_timeCnt;

		//���b�V�����
		LPD3DXMESH m_MeshModel;

		//�}�e���A�����
		LPD3DXBUFFER m_BuffMatModel;

		//�}�e���A�����̏��
		DWORD m_numMatModel;

		D3DXMATRIX m_mtxWorldModel;

		//�N���X�̃R�s�[
		CRenderer *rendererScneX;

		LPDIRECT3DDEVICE9 m_D3DDevice;

		D3DXQUATERNION  m_Quatenion;

		//OpenAL�ɂ��SE�쐬�o�b�t�@
		ALuint m_Buffer;

		ALuint m_Source;

	public:

		CPlayer();
		~CPlayer();

		void Init( void );
		void Uninit( void );
		void Update( void );
		void Draw( void );

		static CPlayer *CPlayer::Create( void );

		D3DXVECTOR3 GetPosition( D3DXVECTOR3 pos );
		D3DXVECTOR3 GetRotation( D3DXVECTOR3 rot );
		D3DXVECTOR3 GetBreadCrumb( D3DXVECTOR3 pos );
};

#endif