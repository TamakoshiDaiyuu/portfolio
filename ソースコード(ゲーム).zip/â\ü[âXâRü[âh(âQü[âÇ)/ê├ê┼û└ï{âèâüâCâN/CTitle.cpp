//-----------------------------------------------------------------
//GM31
//AT13B284 26 �ʉz��Y
//�쐬��
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
// include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CMeshField.h"
#include "CTitle.h"
#include "CInput.h"
#include "CSound_OpenAL.h"
#include "scene2D.h"
#include "CWall.h"
#include "CPlayer.h"
#include "CFade.h"
#include "scoreTexture.h"

#include "CCamera.h"
//-----------------------------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// �}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// �N���X�̐���
//-----------------------------------------------------------------
CTitle::CTitle()
{

}

//-----------------------------------------------------------------
// �N���X�̔j��
//-----------------------------------------------------------------
CTitle::~CTitle()
{

}

//-----------------------------------------------------------------
// ����������
//-----------------------------------------------------------------
void CTitle::Init( void )
{
	CManager *manager = GetManager();
	CRenderer *renderer = manager->GetRenderer();

	//CMeshField::Create();
	//CWall::Create();
	//CPlayer::Create();

	/*CScene2D::Create( "data/TEXTURE/TitleLogo001.png" , 100.0f , 100.0f , 500.0f , 300.0f );
	CScene2D::Create( "data/TEXTURE/TitleLogo002.png" , 200.0f , 300.0f , 200.0f , 200.0f );
	CScene2D::Create( "data/TEXTURE/pressEnter001.png" , 600.0f , 500.0f , 400.0f , 200.0f );*/

	CScene2D::Create( "data/TEXTURE/resultLogo001.png" , 400.0f , 100.0f , 400.0f , 200.0f );

	CFade::Create();

}

//-----------------------------------------------------------------
// �I������
//-----------------------------------------------------------------
void CTitle::Uninit( void )
{
	CScene::UninitAll();
}

//-----------------------------------------------------------------
// �X�V����
//-----------------------------------------------------------------
void CTitle::Update( void )
{
	//�t�F�[�h�Ɏg���ϐ�
	int fadeMode;

	CManager *manager = GetManager();
	CInput *Input = manager->GetInput();
	CFade *fade			= manager->GetFade();

	CScene::UpdateAll();

	fadeMode = fade->GetFade();

	if( fadeMode == FADE_NONE )
	{

	}

	//��ʑJ��
	if( Input->GetKeyboardTrigger( DIK_RETURN ) )
	{
		fade->SetFade( FADE_OUT , MODE_GAME );
	}

}

//-----------------------------------------------------------------
// �`�揈��
//-----------------------------------------------------------------
void CTitle::Draw( void )
{
	CManager *manager = GetManager();
	CCamera *camera =manager->GetCamera();
	CRenderer *renderer = manager->GetRenderer();

	renderer->DrawBegin();

	camera->Draw();
	//SCENE�֘A�`��
	CScene::DrawAll();

	renderer->DrawEnd();
}
