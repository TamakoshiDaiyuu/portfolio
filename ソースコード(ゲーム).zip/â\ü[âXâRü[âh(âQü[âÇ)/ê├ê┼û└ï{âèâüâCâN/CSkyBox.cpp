//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CSkyBox.h"
#include "CInput.h"
#include "CCamera.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Rnderer�N���X�̐���
//-----------------------------------------------------------------
CSkyBox::CSkyBox()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CSkyBox::~CSkyBox()
{

}

//-----------------------------------------------------------------
//����������
//-----------------------------------------------------------------
void CSkyBox::Init( void )
{
	float boxWidth = 5000.0f;

	float boxHeight = 4500.0f;

	float boxZ = 5000.0f;

	CManager *manager = GetManager();

	m_D3DDevice = NULL;

	//�e�N�X�`���ւ̃|�C���^�[
	m_TexturePolygon = NULL;

	renderer = manager->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	if( FAILED ( m_D3DDevice->CreateVertexBuffer( sizeof( TYPE_RENDERER_VERTEX_3D ) * 24 , D3DUSAGE_WRITEONLY ,
												FVF_VERTEX_3D ,
												D3DPOOL_MANAGED , &m_VtxBuffField , NULL ) ) );

	//�e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile( m_D3DDevice , "data/TEXTURE/field_005.jpg" , &m_TexturePolygon );

	//-----------------------------------------------------------------

	TYPE_RENDERER_VERTEX_3D *pVtx;

	//D3DXVECTOR3 vec0 , vec1 , n1 , n2 , n3 , n4;

	//�g�������ς����b�N����
	m_VtxBuffField -> Lock( 0 , 0 , ( void** )&pVtx , 0 );

	//�|���S���̍��W(����)
	pVtx[ 0 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , boxZ );
	pVtx[ 1 ].pos = D3DXVECTOR3( boxWidth , 0.0f , boxZ );
	pVtx[ 2 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , -boxZ );
	pVtx[ 3 ].pos = D3DXVECTOR3( boxWidth , 0.0f , -boxZ );

	//-----------------------------------------------------------------

	//�|���S���̍��W(���)
	pVtx[ 4 ].pos = D3DXVECTOR3( boxWidth , boxHeight , boxZ );
	pVtx[ 5 ].pos = D3DXVECTOR3( -boxWidth , boxHeight , boxZ );
	pVtx[ 6 ].pos = D3DXVECTOR3( boxWidth , boxHeight , -boxZ );
	pVtx[ 7 ].pos = D3DXVECTOR3( -boxWidth , boxHeight , -boxZ );

	//-----------------------------------------------------------------

	//�|���S���̍��W(����)
	pVtx[ 8 ].pos = D3DXVECTOR3( -boxWidth , boxHeight + 10 , -boxZ );
	pVtx[ 9 ].pos = D3DXVECTOR3( -boxWidth , boxHeight + 10 , boxZ );
	pVtx[ 10 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , -boxZ );
	pVtx[ 11 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , boxZ );

	//-----------------------------------------------------------------

	//�|���S���̍��W(�E��)
	pVtx[ 12 ].pos = D3DXVECTOR3( boxWidth , boxHeight + 10 , boxZ );
	pVtx[ 13 ].pos = D3DXVECTOR3( boxWidth , boxHeight + 10 , -boxZ );
	pVtx[ 14 ].pos = D3DXVECTOR3( boxWidth , 0.0f , boxZ );
	pVtx[ 15 ].pos = D3DXVECTOR3( boxWidth , 0.0f , -boxZ );

	//-----------------------------------------------------------------

	//�|���S���̍��W(����)
	pVtx[ 16 ].pos = D3DXVECTOR3( -boxWidth , boxHeight , boxZ );
	pVtx[ 17 ].pos = D3DXVECTOR3( boxWidth , boxHeight , boxZ );
	pVtx[ 18 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , boxZ );
	pVtx[ 19 ].pos = D3DXVECTOR3( boxWidth , 0.0f , boxZ );

	//-----------------------------------------------------------------

	//�|���S���̍��W(��O��)
	pVtx[ 20 ].pos = D3DXVECTOR3( boxWidth , boxHeight , -boxZ );
	pVtx[ 21 ].pos = D3DXVECTOR3( -boxWidth , boxHeight , -boxZ );
	pVtx[ 22 ].pos = D3DXVECTOR3( boxWidth , 0.0f , -boxZ );
	pVtx[ 23 ].pos = D3DXVECTOR3( -boxWidth , 0.0f , -boxZ );

	//-----------------------------------------------------------------

	for( int aCnt = 0 ; aCnt < 24 ; aCnt++ )
	{

		pVtx[ aCnt ].nor = D3DXVECTOR3( 0.0f , 1.0f , 0.0f );

		pVtx[ aCnt ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	}

	//-----------------------------------------------------------------

	//�e�N�X�`���̍��W(����)
	pVtx[ 0 ].tex = D3DXVECTOR2( 0.25f , 0.55f );
	pVtx[ 1 ].tex = D3DXVECTOR2( 0.5f , 0.55f );
	pVtx[ 2 ].tex = D3DXVECTOR2( 0.25f , 1.0f );
	pVtx[ 3 ].tex = D3DXVECTOR2( 0.5f , 1.0f );

	//�e�N�X�`���̍��W(���)
	pVtx[ 7 ].tex = D3DXVECTOR2( 0.25f , 0.0f );
	pVtx[ 6 ].tex = D3DXVECTOR2( 0.5f , 0.0f );
	pVtx[ 5 ].tex = D3DXVECTOR2( 0.25f , 0.33f );
	pVtx[ 4 ].tex = D3DXVECTOR2( 0.5f , 0.33f );

	//�e�N�X�`���̍��W(����)
	pVtx[ 8 ].tex = D3DXVECTOR2( 0.0f , 0.336f );
	pVtx[ 9 ].tex = D3DXVECTOR2( 0.25f , 0.336f );
	pVtx[ 10 ].tex = D3DXVECTOR2( 0.0f , 0.6f );
	pVtx[ 11 ].tex = D3DXVECTOR2( 0.25f , 0.6f );

	//�e�N�X�`���̍��W(�E��)
	pVtx[ 12 ].tex = D3DXVECTOR2( 0.5f , 0.336f );
	pVtx[ 13 ].tex = D3DXVECTOR2( 0.75f , 0.336f );
	pVtx[ 14 ].tex = D3DXVECTOR2( 0.5f , 0.6f );
	pVtx[ 15 ].tex = D3DXVECTOR2( 0.75f , 0.6f );

	//�e�N�X�`���̍��W(����)
	pVtx[ 16 ].tex = D3DXVECTOR2( 0.25f , 0.336f );
	pVtx[ 17 ].tex = D3DXVECTOR2( 0.5f , 0.336f );
	pVtx[ 18 ].tex = D3DXVECTOR2( 0.25f , 0.6f );
	pVtx[ 19 ].tex = D3DXVECTOR2( 0.5f , 0.6f );

	//�e�N�X�`���̍��W(��O��)
	pVtx[ 20 ].tex = D3DXVECTOR2( 0.75f , 0.336f );
	pVtx[ 21 ].tex = D3DXVECTOR2( 1.0f , 0.336f );
	pVtx[ 22 ].tex = D3DXVECTOR2( 0.75f , 0.6f );
	pVtx[ 23 ].tex = D3DXVECTOR2( 1.0f , 0.6f );

	//LOCK����
	m_VtxBuffField->Unlock();
}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CSkyBox::Uninit( void )
{
	if( &m_VtxBuffField != NULL )
	{
		//�I������
		m_VtxBuffField->Release();
		m_VtxBuffField = NULL;
	}

		if( &m_TexturePolygon != NULL )
	{
		//�I������
		m_TexturePolygon->Release();
		m_TexturePolygon = NULL;
	}
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CSkyBox::Update( void )
{
	CManager *manager = GetManager();

	CInput *Input = manager->GetInput();
}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CSkyBox::Draw( void )
{
	CManager *manager = GetManager();

	CRenderer *renderer = manager->GetRenderer();

	CCamera *camera = manager->GetCamera();

	m_D3DDevice = renderer->GetDevice();

	//-------------------------------------------
	//3D�̕`��ݒ�
	//-------------------------------------------

	//�ʒu���
	D3DXMATRIX mtxScl , mtxRot , mtxTrans;

	//���[���h�}�g���b�N�X�̏�����
	D3DXMatrixIdentity( &m_mtxWorldField );

	//�X�P�[���𔽉f
	D3DXMatrixScaling( &mtxScl , 1.0f , 1.0f , 1.0f );

	D3DXMatrixMultiply( &m_mtxWorldField , &m_mtxWorldField, &mtxScl );

	//��]
	D3DXMatrixRotationYawPitchRoll( &mtxRot , 0.0f , 0.0f , 0.0f );

	D3DXMatrixMultiply( &m_mtxWorldField , &m_mtxWorldField , &mtxRot );

	//�ʒu�𔽉f
	D3DXMatrixTranslation( &mtxTrans , camera->m_Camera.posR.x , 0.0f , camera->m_Camera.posR.z );

	D3DXMatrixMultiply( &m_mtxWorldField , &m_mtxWorldField, &mtxTrans );

	m_D3DDevice->SetTransform( D3DTS_WORLD , &m_mtxWorldField );

	//-------------------------------------------

	//���_�o�b�t�@���f�[�^�X�g���[���Ƀo�C���h( �g�ݍ��킹 )
	m_D3DDevice->SetStreamSource( 0 , m_VtxBuffField , 0 , sizeof( TYPE_RENDERER_VERTEX_3D ) );

	//���_�t�H�[�}�b�g�ݒ�
	m_D3DDevice->SetFVF( FVF_VERTEX_3D );

	//�e�N�X�`���̐ݒ�
	m_D3DDevice->SetTexture( 0 , m_TexturePolygon );

	//�|���S���̕`��

	//��pDevice->DrawPrimitive( �v���~�e�B�u�̎�� , �ŏ��̒��_�̃C���f�b�N�X , �`�悷��v���~�e�B�u�̐� );
	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 0 , 2 );

	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 4 , 2 );

	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 8 , 2 );

	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 12 , 2 );

	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 16 , 2 );

	m_D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP , 20 , 2 );
}

CSkyBox *CSkyBox::Create( void )
{
	CSkyBox *skyBox;

	skyBox = new CSkyBox;

	skyBox->Init();

	return skyBox;
}