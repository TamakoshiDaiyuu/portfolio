﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{
    //攻撃を受けた際のオブジェクト色変更
    public Color m_FlashDamageColor = Color.white;

    private MeshRenderer m_MeshRenderer = null;
    private Color m_OriginalColor = Color.white;

    public int m_MaxHealth = 2;
    public int m_GenerateValue = 1;
    public bool DestroyMode = false;

    public Vector3 m_MinPosition = new Vector3(-10f, 5f, 10);
    public Vector3 m_MaxPosition = new Vector3(10f, 15f, 20);

    private float m_GenerateInterval;
    private int m_Health = 0;
    private int m_DestroyCount;

    private void Awake()
    {
        m_MeshRenderer = GetComponent<MeshRenderer>();
        m_OriginalColor = m_MeshRenderer.material.color;
    }

    private void OnEnable()
    {
        ResetHealth();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Projectile"))
            Damage();
    }

    private void Damage()
    {
        StopAllCoroutines();
        StartCoroutine(Flash());

        RemoveHealth();
    }

    private IEnumerator Flash()
    {
        //ダメージを受けた際の点滅処理
        m_MeshRenderer.material.color = m_FlashDamageColor;

        WaitForSeconds wait = new WaitForSeconds(0.1f);
        yield return wait;

        m_MeshRenderer.material.color = m_OriginalColor;
    }

    private void RemoveHealth()
    {
        m_Health--;
        CheckForDeath();
    }

    private void ResetHealth()
    {
        m_Health = m_MaxHealth;
    }

    private void CheckForDeath()
    {
        if (m_Health <= 0)
        {
            if (DestroyMode == false)
            {
                ChangePosition();
            }
            else
            {
                Kill();
            }
        }

    }

    private void Kill()
    {
        //gameObject.SetActive(false);
        Destroy(this.gameObject);
    }
    private void ChangePosition()
    {
        Vector3 position;

        position.x = Random.Range(m_MinPosition.x, m_MaxPosition.x);
        position.y = Random.Range(m_MinPosition.y, m_MaxPosition.y);
        position.z = Random.Range(m_MinPosition.z, m_MaxPosition.z);

        this.transform.position = position;

        m_DestroyCount++;
    }

    public int GetDestroyCount()
    {
        return m_DestroyCount;
    }
}
