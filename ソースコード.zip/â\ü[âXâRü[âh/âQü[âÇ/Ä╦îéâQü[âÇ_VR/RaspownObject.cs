﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaspownObject : MonoBehaviour
{
    public GameObject m_EnemyPrefab;

    public float m_MinTime = 2f;
    public float m_MaxTime = 5f;

    public Vector3 m_MinPosition = new Vector3( -10f, 5f, 10);
    public Vector3 m_MaxPosition = new Vector3( 10f, 15f, 20);

    public bool m_Generate = false;

    private float m_Interval;

    private float m_Time = 0f;

    // Start is called before the first frame update
    void Start()
    {
        m_Interval = GetRandomTime();

        //インスタンス化
        GameObject enemy = Instantiate(m_EnemyPrefab);

        //生成した敵の座標を指定
        enemy.transform.position = new Vector3(this.transform.position.x + GetRandomPosition().x, 
                                               this.transform.position.y + GetRandomPosition().y, 
                                               this.transform.position.z + GetRandomPosition().z);
    }

    // Update is called once per frame
    void Update()
    {
        if(m_Generate == true)
        {
            EnemyGenerater();
        }
        else
        {
            //EnemyGenerater();

            //m_Generate = fal
        }
    }

    private void EnemyGenerater()
    {
        //時間計測
        m_Time += Time.deltaTime;

        //生成する時間になった際の処理
        if (m_Time >= m_Interval)
        {
            //インスタンス化
            GameObject enemy = Instantiate(m_EnemyPrefab);

            //生成した敵の座標を指定
            enemy.transform.position = new Vector3(this.transform.position.x + GetRandomPosition().x , this.transform.position.y + GetRandomPosition().y , this.transform.position.z + GetRandomPosition().z);

            //経過時間の初期化
            m_Time = 0;

            m_Interval = GetRandomTime();
        }
    }

    private float GetRandomTime()
    {
        return Random.Range(m_MinTime , m_MaxTime);

    }
    private Vector3 GetRandomPosition()
    {
        Vector3 position;

        position.x = Random.Range(m_MinPosition.x, m_MaxPosition.x);
        position.y = Random.Range(m_MinPosition.y, m_MaxPosition.y);
        position.z = Random.Range(m_MinPosition.z, m_MaxPosition.z);

        return position;
    }
}
