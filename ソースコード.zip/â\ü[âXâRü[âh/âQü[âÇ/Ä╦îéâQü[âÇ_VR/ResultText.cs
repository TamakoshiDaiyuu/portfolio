﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultText : MonoBehaviour
{
    public float m_TimeInterval = 0f;
    private float m_Time = 0f;

    private Text m_Text;

    // Start is called before the first frame update
    void Start()
    {
        this.transform.GetChild(0).gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void ActiveText()
    {
        if(m_Time < m_TimeInterval)
        {
            m_Time -= Time.deltaTime;
        }
    }
}
