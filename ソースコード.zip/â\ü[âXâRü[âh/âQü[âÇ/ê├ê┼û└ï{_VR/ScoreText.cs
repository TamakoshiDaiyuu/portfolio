﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreText : MonoBehaviour
{
    private GameObject[] tagObjects;

    private TextMesh m_ScoreText;
    private int m_Score;

    // Start is called before the first frame update
    void Start()
    {
        m_ScoreText = GameObject.Find("ScoreText").GetComponent<TextMesh>();
        tagObjects = GameObject.FindGameObjectsWithTag("Crystal");
        m_Score = tagObjects.Length;
    }

    // Update is called once per frame
    void Update()
    {
        tagObjects = GameObject.FindGameObjectsWithTag("Crystal");
        m_Score = tagObjects.Length;
        m_ScoreText.text = "" + m_Score;
    }
}
