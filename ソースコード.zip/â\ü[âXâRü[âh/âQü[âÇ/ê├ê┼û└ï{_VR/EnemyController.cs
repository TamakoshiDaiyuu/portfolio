﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour
{
    public GameObject targetObject; //目標のオブジェクト
    private NavMeshAgent m_NavAgent;

    // Start is called before the first frame update
    void Start()
    {
        m_NavAgent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        if(m_NavAgent.pathStatus != NavMeshPathStatus.PathInvalid)
        {
            m_NavAgent.SetDestination(targetObject.transform.position);
        }
    }
}
