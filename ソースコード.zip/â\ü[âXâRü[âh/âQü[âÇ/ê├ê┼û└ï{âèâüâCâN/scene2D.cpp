//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "scene2D.h"
#include "CInput.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
char *m_fileName;

float g_posX;
float g_posY;
float g_width;
float g_height;
//-----------------------------------------------------------------
// �N���X�̐���
//-----------------------------------------------------------------
CScene2D::CScene2D()
{

}

//-----------------------------------------------------------------
// �N���X�̔j��
//-----------------------------------------------------------------
CScene2D::~CScene2D()
{

}

//-----------------------------------------------------------------
// ����������
//-----------------------------------------------------------------
void CScene2D::Init( void )
{
	CManager *maneger = GetManager();

	m_D3DDevice = NULL;

	//�e�N�X�`���ւ̃|�C���^�[
	m_TexturePolygon = NULL;

	renderer = maneger->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	//�e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile( m_D3DDevice , m_fileName , &m_TexturePolygon );

	//�|���S���̍��W
	m_ScneVertex2D[ 0 ].pos = D3DXVECTOR3( g_posX , g_posY , 0.0f );
	m_ScneVertex2D[ 1 ].pos = D3DXVECTOR3( g_posX + g_width , g_posY , 0.0f );
	m_ScneVertex2D[ 2 ].pos = D3DXVECTOR3( g_posX , g_posY + g_height , 0.0f );
	m_ScneVertex2D[ 3 ].pos = D3DXVECTOR3( g_posX + g_width , g_posY + g_height , 0.0f );

	m_ScneVertex2D[ 0 ].rhw = 1.0f;
	m_ScneVertex2D[ 1 ].rhw = 1.0f;
	m_ScneVertex2D[ 2 ].rhw = 1.0f;
	m_ScneVertex2D[ 3 ].rhw = 1.0f;

	m_ScneVertex2D[ 0 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 1 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 2 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 3 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );

	//�e�N�X�`���̍��W
	m_ScneVertex2D[ 0 ].tex = D3DXVECTOR2( 0.0f , 0.0f );
	m_ScneVertex2D[ 1 ].tex = D3DXVECTOR2( 1.0f , 0.0f );
	m_ScneVertex2D[ 2 ].tex = D3DXVECTOR2( 0.0f , 1.0f );
	m_ScneVertex2D[ 3 ].tex = D3DXVECTOR2( 1.0f , 1.0f );

}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CScene2D::Uninit( void )
{
	if( m_TexturePolygon != NULL )
	{
		//�e�N�X�`���̏I������
		m_TexturePolygon->Release();
		m_TexturePolygon = NULL;
	}

}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CScene2D::Update( void )
{
	CManager *manager = GetManager();

	CInput *Input = manager->GetInput();

	if( Input->GetKeyboardTrigger( DIK_DELETE ) )
	{
		Uninit();
		//Release();
	}

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CScene2D::Draw( void )
{
	CManager *manager = GetManager();

	CRenderer *renderer = manager->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	//�t�H�[�}�b�g�ݒ�
	m_D3DDevice->SetFVF( FVF_VERTEX_2D );

	//�e�N�X�`���̐ݒ�
	m_D3DDevice->SetTexture( 0 , m_TexturePolygon );

	//�|���S���̕`��
	m_D3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP , 2 , &m_ScneVertex2D[ 0 ] , sizeof( VECTOR2D ) );
}

CScene2D *CScene2D::Create( char *fileName , float posX , float posY , float Width , float Height )
{
	CScene2D *scene2D;

	scene2D = new CScene2D;

	m_fileName = fileName;

	g_posX		= posX;
	g_width		= Width;
	g_posY		= posY;
	g_height	= Height;

	scene2D->Init();

	return scene2D;
}