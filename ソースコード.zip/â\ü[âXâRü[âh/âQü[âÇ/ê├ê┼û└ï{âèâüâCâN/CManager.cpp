//-----------------------------------------------------------------
// GM31 ���Q�[��
// AT13B284 26 �ʉz��Y
// �쐬��2016/04/18
// �C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
// include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CInput.h"
#include "CMeshField.h"
#include "CWall.h"
#include "scene.h"
#include "scene2D.h"
#include "scene3D.h"
#include "sceneX.h"
#include "CCamera.h"
#include "CLight.h"
#include "CSkyBox.h"
#include "CSound_OpenAL.h"
#include "CSave.h"
#include "CEnemy.h"
#include "CScoreItem.h"
#include "CScore.h"
#include "scoreTexture.h"
#include "CBillBord.h"
#include "CPlayer.h"

#include "CFade.h"
#include "CTitle.h"
#include "CGame.h"
#include "CResult.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
MODE m_mode;
//-----------------------------------------------------------------
// �N���X�̐���
//-----------------------------------------------------------------
CManager::CManager()
{
	m_Camera = NULL;
}

//-----------------------------------------------------------------
// �N���X�̔j��
//-----------------------------------------------------------------
CManager::~CManager()
{

}

//-----------------------------------------------------------------
// ����������
//-----------------------------------------------------------------
void CManager::Init( HINSTANCE hInstance , HWND hWnd , BOOL bWindow )
{
	// ---�X�e�[�W�Ɏg���֐�������---
	m_mode		= MODE_MAX;
	m_modeScean = MODE_RESULT;

	//---�C���X�^���X����---
	m_Input		= new CInput;
	m_Renderer  = new CRenderer;
	m_Camera	= new CCamera;
	m_Light		= new CLight;
	CSave *save = new CSave;

	//m_SoundAL = new CSound_OpenAL;

	//---����������---

	m_Input->InitKeyboard( hInstance , hWnd );		// ���͏����̏�����
	m_Input->InitInput( hInstance , hWnd );
	m_Input->InitMouse( hInstance , hWnd );

	m_Camera->Init();								// �J�����̏�����
	m_Renderer->Init( hInstance , hWnd , bWindow );	// �����_�\����
	m_Light->Init();								// ���C�g�̏���

	//�T�E���h�쐬
	CSound_OpenAL::Init();
	//CSound_OpenAL::Play( 0 );

	//// ---�N���G�C�g�֐�---
	//CSkyBox::Create();				// �X�J�C�{�b�N�X
	//CMeshField::Create();
	//CWall::Create();
	//CScoreItem::Create();
	//CPlayer::Create();
	////CSceneX::Create();
	////CSceneX::Create();				// ���f���쐬
	//CEnemy::Create();

	//// ---�QD�I�u�W�F�N�g---
	//CBillBord::Create();
	//CScore::Create();
	//scoreTexture::Create();

	//��ʑJ��
	SetMode( m_modeScean );
}

//-----------------------------------------------------------------
// �I������
//-----------------------------------------------------------------
void CManager::Uninit( void )
{
	//---�I������---
	m_Renderer->Uninit();
	m_Light->Uninit();
	m_Input->UninitKeyboard();
	m_Input->UninitMouse();

	if( m_Camera != NULL )
	{
		m_Camera->Uninit();
		m_Camera = NULL;
	}

	CScene::UninitAll();
	CSound_OpenAL::Uninit();

	//---delete����---
	delete m_Camera;
	delete m_Renderer;
	delete m_Input;
	delete m_Light;

	switch( m_mode )
	{
		case MODE_TITLE:
			m_Title->Uninit();
			break;

		case MODE_GAME:
			m_Game->Uninit();
			break;

		case MODE_RESULT:
			m_Result->Uninit();
			break;
	}

}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CManager::Update( void )
{

	m_Input->UpdateKeyboard();
	m_Input->UpdateMouse();

	m_Renderer->Update();
	m_Camera->Update();

	m_Light->Update();

	CScene::UpdateAll();

	switch( m_mode )
	{
		case MODE_TITLE:
			m_Title->Update();
			break;

		case MODE_GAME:
			m_Game->Update();
			break;

		case MODE_RESULT:
			m_Result->Update();
			break;
	}

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CManager::Draw( void )
{

	LPDIRECT3DDEVICE9 D3DDevice;

	D3DDevice = m_Renderer->GetDevice();

	//m_Renderer->DrawBegin();

	/*m_Light->SetLight();*/
	//m_Camera->Draw();		//�J����
	//CScene::DrawAll();		//SCENE�֘A�`��

	switch( m_mode )
	{
		case MODE_TITLE:
			m_Title->Draw();
			break;

		case MODE_GAME:
			m_Game->Draw();
			break;

		case MODE_RESULT:
			m_Result->Draw();
			break;
	}

	//m_Renderer->DrawEnd();
}

//-----------------------------------------------------------------
//�X�e�b�v�X�e�[�W
//-----------------------------------------------------------------
void CManager::SetMode( MODE mode )
{
	switch( m_mode )
	{
		case MODE_TITLE:
			m_Title->Uninit();
			break;

		case MODE_GAME:
			m_Game->Uninit();
			break;

		case MODE_RESULT:
			m_Result->Uninit();
			break;

		case MODE_MAX:

			break;
	}

	switch( mode )
	{
		case MODE_TITLE:
			m_Title->Init();
			break;

		case MODE_GAME:
			m_Camera->Init();								// �J�����̏�����
			m_Game->Init();
			break;

		case MODE_RESULT:
			m_Result->Init();
			break;
	}

	m_mode = mode;
}

//-----------------------------------------------------------------
//GET�֐�
//-----------------------------------------------------------------
MODE *CManager::GetMode( MODE mode )
{
	mode = m_mode;
	return &m_mode;
}


//-----------------------------------------------------------------
//GET�֐�
//-----------------------------------------------------------------
CRenderer *CManager::GetRenderer( void )	// �����_���\�N���X�󂯓n��
{
	return m_Renderer;
}
CInput *CManager::GetInput( void )			// �C���v�b�g�N���X�󂯓n��
{
	return m_Input;
}
CCamera *CManager::GetCamera( void )		// �J�����N���X�󂯓n��
{
	return m_Camera;
}
CLight *CManager::GetLight( void )
{
	return m_Light;
}
CSound_OpenAL *CManager::GetSoundAL( void )	// �T�E���h�N���X�󂯓n��
{
	return m_SoundAL;
}
CBullet *CManager::GetBullet( void )// �o���b�g�󂯓n��
{
	return m_Bullet;
}
CSceneX *CManager::GetSceneX( void )// �o���b�g�󂯓n��
{
	return m_SceneX;
}
CSave *CManager::GetSave( void )// �o���b�g�󂯓n��
{
	return m_Save;
}
CScoreItem *CManager::GetScoreItem( void )
{
	return m_ScoreItem;
}
CWall *CManager::GetWall( void )
{
	return m_Wall;
}
CScore *CManager::GetScore( void )
{
	return m_Score;
}
CPlayer *CManager::GetPlayer( void )
{
	return m_Player;
}
CFade *CManager::GetFade( void )
{
	return m_Fade;
}
CEnemy *CManager::GetEnemy( void )
{
	return m_Enemy;
}