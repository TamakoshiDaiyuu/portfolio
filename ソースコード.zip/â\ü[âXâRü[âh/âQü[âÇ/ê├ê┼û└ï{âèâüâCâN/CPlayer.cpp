//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CPlayer.h"
#include "CInput.h"
#include "CCamera.h"
#include "CSound_OpenAL.h"
#include "CWall.h"
#include "CScoreItem.h"
//-----------------------------------------------------------------
//�f�t�@�C����`
//-----------------------------------------------------------------
#define MODEL_MOVE ( 1.0f )
//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
//���f���̏��
MODEL m_Player[ 1 ];

D3DXVECTOR3 m_BreadCrumb[ MAX_BREADCRUM ];
bool m_BreadCrumbUse[ MAX_BREADCRUM ];
//-----------------------------------------------------------------
//�N���X�̐���
//-----------------------------------------------------------------
CPlayer::CPlayer()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CPlayer::~CPlayer()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
void CPlayer::Init( void )
{
	CManager *manager;

	manager = GetManager();

	m_D3DDevice = NULL;

	rendererScneX = manager->GetRenderer();

	m_D3DDevice = rendererScneX->GetDevice();

	CSound_OpenAL::Init();

	//--------- �ϐ������� ---------
	m_timeCnt = 0;

	//�N�I�[�^�j�I��������
	D3DXQuaternionIdentity( &m_Quatenion );

	for( int aCnt = 0 ; aCnt < MAX_BREADCRUM - 1 ; aCnt++ )
	{
		m_BreadCrumb[ aCnt ] = D3DXVECTOR3( -150.0f , 500.0f , -10.0f );

		m_BreadCrumbUse[ aCnt ] = false;
	}

	//���f���\���̏�����
	for( int aCnt = 0 ; aCnt < 1 ; aCnt++ )
	{
		//�ϐ�������
		m_Player[ aCnt ].pos = D3DXVECTOR3( -150.0f , 500.0f , -160.0f );

		m_Player[ aCnt ].move = D3DXVECTOR3( 0.0f , 0.006f , 0.0f );

		m_Player[ aCnt ].rot = D3DXVECTOR3( 0.0f , -D3DX_PI , 0.0f );

		m_Player[ aCnt ].scl = D3DXVECTOR3( 1.0f , 1.0f , 1.0f );

		//���f���̎g�p���
		m_Player[ aCnt ].bUse = false;

		//�W�����v�̎g�p���
		m_Player[ aCnt ].bJump = false;

		//���f�����ړ����
		m_Player[ aCnt ].bUseMove = false;

	}

	//�}�e���A����񏉊���
	D3DXLoadMeshFromX( "data/MODEL/shine.x" ,
						D3DXMESH_SYSTEMMEM ,
						m_D3DDevice ,
						NULL ,
						&m_BuffMatModel ,
						NULL ,
						&m_numMatModel ,
						&m_MeshModel );

}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CPlayer::Uninit( void )
{

	CSound_OpenAL::Uninit();

	if( &m_MeshModel != NULL )
	{
		//�e�N�X�`���̏I������
		m_MeshModel->Release();
		m_MeshModel = NULL;
	}

	if( &m_BuffMatModel != NULL )
	{
		//�e�N�X�`���̏I������
		m_BuffMatModel->Release();
		m_BuffMatModel = NULL;
	}
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CPlayer::Update( void )
{
	//�N�I�[�^�j�I���Ɏg���ϐ�
	D3DXVECTOR3 axis;
	D3DXQUATERNION quat;

	//--- �J�����̏�� ---
	D3DXVECTOR3 cameraRot;

	// ---�N���X�̎󂯎��---
	CManager *manager = GetManager();
	CInput *Input = manager->GetInput();
	CSound_OpenAL *soundAL = manager->GetSoundAL();
	CCamera *camera =manager->GetCamera();
	CScoreItem *ScoreItem = manager->GetScoreItem();
	CWall *wall = manager->GetWall();

	cameraRot = camera->GetRotation( cameraRot );

	m_Player[ 0 ].pos = wall->CollisionWall( m_Player[ 0 ].pos );

	m_timeCnt++;

	for( int aCnt = 0 , frame = 100 ; aCnt < MAX_BREADCRUM ; aCnt++ )
	{
		if( m_timeCnt > frame )
		{
			if( m_BreadCrumbUse[ aCnt ] == false )
			{
				m_BreadCrumb[ aCnt ] = m_Player[ 0 ].pos;

				m_BreadCrumbUse[ aCnt ] = true;

				m_timeCnt = 0 ;

			}
		}

		/*if( aCnt == MAX_BREADCRUM - 1 )
		{
			m_timeCnt = 0 ;

			for( int aCnt2 = 0 ; aCnt < MAX_BREADCRUM - 1 ; aCnt2++ )
			{
				m_BreadCrumbUse[ aCnt2 ] = false;
			}
		}*/
	}

	if( m_timeCnt > 100 )
	{
		m_timeCnt = 0;

		for( int aCnt = 0 , frame = 100 ; aCnt < MAX_BREADCRUM - 1 ; aCnt++ )
		{
			m_BreadCrumbUse[ aCnt ] = false;
		}
	}

	//-------------------------------------------
	//���̂����蔻��
	//-------------------------------------------

	//-------------------------------------------
	//---�ړ�����---�ЂȌ^�Ȃ�����Ă�����
	//-------------------------------------------

	m_Player[ 0 ].bUseMove = false;

	if( Input->GetKeyboardPress( DIK_UP ) )
	{
		//���K���i��]�l�𐳂����l�ɕϊ��j
		if( m_Player[ 0 ].rot.y > D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y - ( D3DX_PI * 2 );
		}
		else if( m_Player[ 0 ].rot.y < -D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y + ( D3DX_PI * 2 );
		}

		//�ړ�����l
		m_Player[ 0 ].pos.x -= sinf( cameraRot.y ) * MODEL_MOVE;

		m_Player[ 0 ].pos.z -= cosf( cameraRot.y ) * MODEL_MOVE;
	}
	if( Input->GetKeyboardPress( DIK_DOWN ) )
	{
		m_Player[ 0 ].pos.z -= 2;
		//CSound_OpenAL::Play( 2 );	// �T�E���h�쐬
	}
	if( Input->GetKeyboardPress( DIK_LEFT ) )
	{
			m_Player[ 0 ].bUseMove = true;

			//��]�ʂ̉��Z
			m_Player[ 0 ].rot.y = D3DX_PI/1.5 + cameraRot.y;

			//���K���i��]�l�𐳂����l�ɕϊ��j
			if( m_Player[ 0 ].rot.y > D3DX_PI )
			{
				m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y - ( D3DX_PI * 2 );
			}
			else if( m_Player[ 0 ].rot.y < -D3DX_PI )
			{
				m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y + ( D3DX_PI * 2 );
			}
	}
	if( Input->GetKeyboardPress( DIK_RIGHT ) )
	{
		m_Player[ 0 ].bUseMove = true;

			//��]�ʂ̉��Z
			m_Player[ 0 ].rot.y = -D3DX_PI/1.5 + cameraRot.y;

			//���K���i��]�l�𐳂����l�ɕϊ��j
			if( m_Player[ 0 ].rot.y > D3DX_PI )
			{
				m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y - ( D3DX_PI * 2 );
			}
			else if( m_Player[ 0 ].rot.y < -D3DX_PI )
			{
				m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y + ( D3DX_PI * 2 );
			}
	}

	// ---------�}�E�X���� ---------
	/*if( Input->GetMouseUp() )
	{
		m_Player[ 0 ].bUseMove =true;

		if( m_Player[ 0 ].rot.x < 0.5f )
		{
			m_Player[ 0 ].rot.x += 0.005f;
		}
	}
	if( Input->GetMouseDown() )
	{
		m_Player[ 0 ].bUseMove =true;

		if( m_Player[ 0 ].rot.x > -0.5f )
		{
			m_Player[ 0 ].rot.x -= 0.005f;
		}
	}*/

	if( Input->GetMouseRight() )
	{
		m_Player[ 0 ].rot.y += 0.04f;
		//m_Player[ 0 ].rot.z += 0.05f;
	}
	if( Input->GetMouseLeft() )
	{
		m_Player[ 0 ].rot.y -= 0.04f;
		//m_Player[ 0 ].rot.z -= 0.05f;
	}

	if( Input->GetMouseRgbButtons( 0 ) )
	{
		//���K���i��]�l�𐳂����l�ɕϊ��j
		if( m_Player[ 0 ].rot.y > D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y - ( D3DX_PI * 2 );
		}
		else if( m_Player[ 0 ].rot.y < -D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y + ( D3DX_PI * 2 );
		}

		//�ړ�����l
		m_Player[ 0 ].pos.x -= sinf( cameraRot.y ) * MODEL_MOVE;

		m_Player[ 0 ].pos.z -= cosf( cameraRot.y ) * MODEL_MOVE;

		//CSound_OpenAL::Play( 2 );	// �T�E���h
	}
	else if( Input->GetMouseRgbButtons( 1 ) )
	{
		//���K���i��]�l�𐳂����l�ɕϊ��j
		if( m_Player[ 0 ].rot.y > D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y - ( D3DX_PI * 2 );
		}
		else if( m_Player[ 0 ].rot.y < -D3DX_PI )
		{
			m_Player[ 0 ].rot.y = m_Player[ 0 ].rot.y + ( D3DX_PI * 2 );
		}

		//�ړ�����l
		m_Player[ 0 ].pos.x += sinf( cameraRot.y ) * MODEL_MOVE;

		m_Player[ 0 ].pos.z += cosf( cameraRot.y ) * MODEL_MOVE;

		//CSound_OpenAL::Play( 2 );	// �T�E���h
	}

	//-------------------------------------------
	//���f�����̍X�V
	//-------------------------------------------
	for( int aCnt = 0 ; aCnt < 1 ; aCnt++ )
	{
		//���f���̈ړ��ʂ����Z
		m_Player[ aCnt ].pos.x += m_Player[ aCnt ].move.x;

		//m_Player[ aCnt ].pos.y += m_Player[ aCnt ].move.y;

		m_Player[ aCnt ].pos.z += m_Player[ aCnt ].move.z;

	}

	// �ړ��ʂ̌���
	if( m_Player[ 0 ].bUseMove == false )
	{
		// ---X���̈ړ��ʌ���---
		if( m_Player[ 0 ].move.x > 0 )
		{
			m_Player[ 0 ].move.x -= 0.01;
		}
		if( m_Player[ 0 ].move.x < 0 )
		{
			m_Player[ 0 ].move.x += 0.01;
		}

		// ---Z���̈ړ��ʌ���---
		if( m_Player[ 0 ].move.z > 0 )
		{
			m_Player[ 0 ].move.z -= 0.01;
		}
		if( m_Player[ 0 ].move.z < 0 )
		{
			m_Player[ 0 ].move.z += 0.01;
		}
	}

	ScoreItem->CollisionCheck( m_Player[ 0 ].pos );

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CPlayer::Draw( void )
{
	//�ʒu���
	D3DXMATRIX mtxScl , mtxRot , mtxTrans;

	//���[���h�}�g���b�N�X�̏�����
	D3DXMatrixIdentity( &m_mtxWorldModel );

	D3DXMATERIAL *pMat;

	//���f���̏��ێ�����ϐ�
	D3DMATERIAL9 matDef;

	CManager *manager;

	manager = GetManager();

	rendererScneX = manager->GetRenderer();

	m_D3DDevice = rendererScneX->GetDevice();

	//-------------------------------------------
	//3D�̕`��ݒ�
	//-------------------------------------------

	//���f���\����
	for( int aCnt = 0 ; aCnt < 1 ; aCnt++ )
	{
		if( m_Player[ aCnt ].bUse == true )
		{
			//�X�P�[���𔽉f
			D3DXMatrixScaling( &mtxScl , m_Player[ aCnt ].scl.x , m_Player[ aCnt ].scl.y , m_Player[ aCnt ].scl.z );

			D3DXMatrixMultiply( &m_mtxWorldModel , &m_mtxWorldModel, &mtxScl );

			D3DXMatrixRotationYawPitchRoll( &mtxRot , m_Player[ aCnt ].rot.y , m_Player[ aCnt ].rot.x , m_Player[ aCnt ].rot.z );
			
			//�N�H�[�e�[�V�����̉�]�}�g���b�N�X
			//D3DXMatrixRotationQuaternion( &mtxRot , &m_Quatenion );

			//��]
			D3DXMatrixMultiply( &m_mtxWorldModel , &m_mtxWorldModel , &mtxRot );

			D3DXMatrixTranslation( &mtxTrans , m_Player[ aCnt ].pos.x , m_Player[ aCnt ].pos.y , m_Player[ aCnt ].pos.z );

			//�ʒu�𔽉f
			D3DXMatrixMultiply( &m_mtxWorldModel , &m_mtxWorldModel, &mtxTrans );

			m_D3DDevice->SetTransform( D3DTS_WORLD , &m_mtxWorldModel );

			//-------------------------------------------

			//���݂̃}�e���A�����̕ێ�
			m_D3DDevice->GetMaterial( &matDef );

			//�ϊ�
			pMat = ( D3DXMATERIAL * )m_BuffMatModel->GetBufferPointer();

			for( int nCntMat = 0 ; nCntMat < ( int )m_numMatModel ; nCntMat++ )
			{
				m_D3DDevice->SetMaterial( &pMat[ nCntMat ].MatD3D );

				//�e�N�X�`���̐ݒ�
				m_D3DDevice->SetTexture( 0 , NULL );

				//���b�V���`��
				m_MeshModel->DrawSubset( nCntMat );

			}

			//�}�e���A��������
			m_D3DDevice->SetMaterial( &matDef );
		}
	}

	
}

//-----------------------------------------------------------------
//GET����
//-----------------------------------------------------------------
D3DXVECTOR3 CPlayer::GetPosition( D3DXVECTOR3 pos )
{
	pos = m_Player[ 0 ].pos;

	pos.y += 60.0f;

	return pos;
}

D3DXVECTOR3 CPlayer::GetRotation( D3DXVECTOR3 rot )
{
	rot = m_Player[ 0 ].rot;

	return rot;
}

D3DXVECTOR3 CPlayer::GetBreadCrumb( D3DXVECTOR3 pos )
{
	pos = m_BreadCrumb[ 1 ];

	pos.y += 30.0f;

	return pos;
}

CPlayer *CPlayer::Create( void )
{
	CPlayer *sceneX;

	sceneX = new CPlayer;

	sceneX->Init();

	return sceneX;

}