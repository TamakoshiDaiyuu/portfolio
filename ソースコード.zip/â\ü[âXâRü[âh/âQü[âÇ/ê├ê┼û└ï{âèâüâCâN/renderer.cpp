//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "renderer.h"

//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
//���_���
VECTOR2D g_pRendererVertex2D[ 4 ];

//���\��( �f�o�b�N�p�p�����[�^�[ )
LPD3DXFONT g_pFont;
//-----------------------------------------------------------------
// Rnderer�N���X�̐���
//-----------------------------------------------------------------
CRenderer::CRenderer()
{

	m_D3D = NULL;
	
	m_D3DDevice = NULL;

	//�e�N�X�`���ւ̃|�C���^�[
	m_TexturePolygon = NULL;

	//3D�I�u�W�F�N�g����
//	m_D3D = Direct3DCreate9( D3D_SDK_VERSION );
}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CRenderer::~CRenderer()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
HRESULT CRenderer::Init( HINSTANCE hInstance , HWND hWnd , BOOL bWindow )
{
	//3D�I�u�W�F�N�g����
	m_D3D = Direct3DCreate9( D3D_SDK_VERSION );

	//���g�������Ă邩�̊m�F
	if( m_D3D == NULL )
	{
		return E_FAIL;
	}

	if( FAILED( m_D3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT , &m_d3ddm ) ) )
	{
		return E_FAIL;
	}

	ZeroMemory( &m_d3dpp , sizeof( m_d3dpp ) );
	m_d3dpp . BackBufferWidth = SCREEN_WIDTH;
	m_d3dpp . BackBufferHeight = SCREEN_HEIGHT;
	m_d3dpp . BackBufferFormat = m_d3ddm.Format;
	m_d3dpp . BackBufferCount = 1;
	m_d3dpp . SwapEffect = D3DSWAPEFFECT_DISCARD;
	m_d3dpp . EnableAutoDepthStencil = TRUE;
	m_d3dpp . AutoDepthStencilFormat = D3DFMT_D16;
	m_d3dpp . Windowed = bWindow;
	m_d3dpp . FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	m_d3dpp . PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;

	if( FAILED( m_D3D->CreateDevice( D3DADAPTER_DEFAULT , D3DDEVTYPE_HAL , hWnd , D3DCREATE_HARDWARE_VERTEXPROCESSING , &m_d3dpp , &m_D3DDevice ) ) )
	{
		if( FAILED( m_D3D->CreateDevice( D3DADAPTER_DEFAULT , D3DDEVTYPE_HAL , hWnd , D3DCREATE_SOFTWARE_VERTEXPROCESSING , &m_d3dpp , &m_D3DDevice ) ) )
		{
			if( FAILED( m_D3D->CreateDevice( D3DADAPTER_DEFAULT , D3DDEVTYPE_REF , hWnd , D3DCREATE_SOFTWARE_VERTEXPROCESSING , &m_d3dpp , &m_D3DDevice ) ) )
			{
				return E_FAIL;
			}
		}
	}

	D3DXCreateFont( m_D3DDevice , 18 , 0 , 0 , 0 , FALSE ,
				SHIFTJIS_CHARSET , OUT_DEFAULT_PRECIS ,
				DEFAULT_QUALITY , DEFAULT_PITCH , "terminal" , &g_pFont );

	//--------- �����_�\�^�[�Q�b�g�p�e�N�X�e���̐��� ---------
	//�|���S���̍��W
	m_Vertex2D[ 0 ].pos = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );
	m_Vertex2D[ 1 ].pos = D3DXVECTOR3( SCREEN_WIDTH , 0.0f , 0.0f );
	m_Vertex2D[ 2 ].pos = D3DXVECTOR3( 0.0f , SCREEN_HEIGHT , 0.0f );
	m_Vertex2D[ 3 ].pos = D3DXVECTOR3( SCREEN_WIDTH , SCREEN_HEIGHT , 0.0f );

	m_Vertex2D[ 0 ].rhw = 1.0f;
	m_Vertex2D[ 1 ].rhw = 1.0f;
	m_Vertex2D[ 2 ].rhw = 1.0f;
	m_Vertex2D[ 3 ].rhw = 1.0f;

	m_Vertex2D[ 0 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D[ 1 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D[ 2 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D[ 3 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );

	//�e�N�X�`���̍��W
	m_Vertex2D[ 0 ].tex = D3DXVECTOR2( 0.0f , 0.0f );
	m_Vertex2D[ 1 ].tex = D3DXVECTOR2( 1.0f , 0.0f );
	m_Vertex2D[ 2 ].tex = D3DXVECTOR2( 0.0f , 1.0f );
	m_Vertex2D[ 3 ].tex = D3DXVECTOR2( 1.0f , 1.0f );

	//�|���S���̍��W
	m_Vertex2D_BT2[ 0 ].pos = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );
	m_Vertex2D_BT2[ 1 ].pos = D3DXVECTOR3( SCREEN_WIDTH , 0.0f , 0.0f );
	m_Vertex2D_BT2[ 2 ].pos = D3DXVECTOR3( 0.0f , SCREEN_HEIGHT , 0.0f );
	m_Vertex2D_BT2[ 3 ].pos = D3DXVECTOR3( SCREEN_WIDTH , SCREEN_HEIGHT , 0.0f );

	m_Vertex2D_BT2[ 0 ].rhw = 1.0f;
	m_Vertex2D_BT2[ 1 ].rhw = 1.0f;
	m_Vertex2D_BT2[ 2 ].rhw = 1.0f;
	m_Vertex2D_BT2[ 3 ].rhw = 1.0f;

	m_Vertex2D_BT2[ 0 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D_BT2[ 1 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D_BT2[ 2 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );
	m_Vertex2D_BT2[ 3 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 245 );

	//�e�N�X�`���̍��W
	m_Vertex2D_BT2[ 0 ].tex = D3DXVECTOR2( 0.0f , 0.0f );
	m_Vertex2D_BT2[ 1 ].tex = D3DXVECTOR2( 1.0f , 0.0f );
	m_Vertex2D_BT2[ 2 ].tex = D3DXVECTOR2( 0.0f , 1.0f );
	m_Vertex2D_BT2[ 3 ].tex = D3DXVECTOR2( 1.0f , 1.0f );

	D3DXCreateTexture( m_D3DDevice , SCREEN_WIDTH , SCREEN_HEIGHT , 1 ,
						D3DUSAGE_RENDERTARGET ,
						D3DFMT_A8R8G8B8 ,
						D3DPOOL_DEFAULT ,
						&m_BlurTexture1);

	m_BlurTexture1->GetSurfaceLevel( 0 , &m_BlurSurface1 );

	D3DXCreateTexture( m_D3DDevice , SCREEN_WIDTH , SCREEN_HEIGHT , 1 ,
						D3DUSAGE_RENDERTARGET ,
						D3DFMT_A8R8G8B8 ,
						D3DPOOL_DEFAULT ,
						&m_BlurTexture2);

	m_BlurTexture2->GetSurfaceLevel( 0 , &m_BlurSurface2 );

	m_D3DDevice->GetRenderTarget( 0 , &m_BackBufferSurface );

	//�����_�[�X�e�[�g�̐ݒ�
	m_D3DDevice->SetRenderState( D3DRS_CULLMODE , D3DCULL_CCW );
	m_D3DDevice->SetRenderState( D3DRS_ALPHABLENDENABLE , TRUE );
	m_D3DDevice->SetRenderState( D3DRS_SRCBLEND , D3DBLEND_SRCALPHA );
	m_D3DDevice->SetRenderState( D3DRS_DESTBLEND , D3DBLEND_INVSRCALPHA );
	m_D3DDevice->SetRenderState( D3DRS_LIGHTING , TRUE );

	//�T���v���X�e�C�g�̐ݒ�
	//�G�b�W�̕␳����
	//�k�����̏���
	m_D3DDevice->SetSamplerState( 0 , D3DSAMP_MINFILTER , D3DTEXF_LINEAR );
	//�g�厞�̏���
	m_D3DDevice->SetSamplerState( 0 , D3DSAMP_MAGFILTER , D3DTEXF_LINEAR );
	//�e�N�X�`��(U�l)
	m_D3DDevice->SetSamplerState( 0 , D3DSAMP_ADDRESSU , D3DTADDRESS_WRAP );
	//�e�N�X�`��(V�l)
	m_D3DDevice->SetSamplerState( 0 , D3DSAMP_ADDRESSV , D3DTADDRESS_WRAP );
	////�e�N�X�`���X�e�[�W�X�e�[�g�̐ݒ�
	m_D3DDevice->SetTextureStageState( 0 , D3DTSS_ALPHAOP , D3DTOP_MODULATE );
	m_D3DDevice->SetTextureStageState( 0 , D3DTSS_ALPHAARG1 , D3DTA_TEXTURE );
	m_D3DDevice->SetTextureStageState( 0 , D3DTSS_ALPHAARG2 , D3DTA_CURRENT );

	return S_OK;
}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CRenderer::Uninit( void )
{
	if( m_D3DDevice != NULL )
	{
		m_D3DDevice -> Release();
		m_D3DDevice = NULL;
	}
	if( m_D3D != NULL )
	{
		m_D3D -> Release();
		m_D3D = NULL;
	}
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CRenderer::Update( void )
{

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CRenderer::DrawBegin( void )
{
	//��ʂ̃N���A
	m_D3DDevice->Clear( 0 , NULL , 
							( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER ) ,
							D3DCOLOR_RGBA( 0 , 0 , 0 , 0 ),
							1.0f , 0 );

	m_D3DDevice->BeginScene();
}

void CRenderer::DrawBlurBegin( void )
{
	m_D3DDevice->SetRenderTarget( 0 , m_BlurSurface1 );

	m_D3DDevice->Clear( 0 , NULL ,
						( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER ) ,
						D3DCOLOR_RGBA( 0 , 0 , 0 , 0 ),
						1.0f , 0 );

	m_D3DDevice->BeginScene();


}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CRenderer::DrawFog( void )
{
	//��ʂ̃N���A
	/*m_D3DDevice->Clear( 0 , NULL , 
							( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER ) ,
							D3DCOLOR_RGBA( 0 , 0 , 0 , 0 ),
							1.0f , 0 );*/

	float FogStart = 0.0f; // �J�n�_
	float FogEnd = 8100.0f; // �I���_
	m_D3DDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);						// �t�H�O��L���ɂ���
	m_D3DDevice->SetRenderState(D3DRS_FOGCOLOR, D3DXCOLOR( 1.0f, 1.0f, 1.0f, 0.5f));// �t�H�O�J���[�ݒ�

	m_D3DDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_NONE);      //���_���[�h
	m_D3DDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);     //�e�[�u�����[�h
	m_D3DDevice->SetRenderState(D3DRS_FOGSTART, *((LPDWORD)(&FogStart)));	// �t�H�O�̊J�n�n�_
	m_D3DDevice->SetRenderState(D3DRS_FOGEND, *((LPDWORD)(&FogEnd)));		// �t�H�O�̏I���n�_
	//�e���������茩����I�I
	m_D3DDevice->SetRenderState( D3DRS_SHADEMODE ,D3DSHADE_FLAT );

}

void CRenderer::DrawEnd( void )
{
	m_D3DDevice->EndScene();

	m_D3DDevice->Present( NULL , NULL , NULL , NULL );

}

void CRenderer::DrawBlurEnd( void )
{

	m_D3DDevice->EndScene();
	m_D3DDevice->BeginScene();

	//--------- �S���2D�|���S���`�� ---------
	m_D3DDevice->SetFVF( FVF_VERTEX_2D );
	m_D3DDevice->SetTexture( 0 , m_BlurTexture2 );
	m_D3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP , 2 , &m_Vertex2D_BT2[ 0 ] , sizeof( VECTOR2D ) );

	m_D3DDevice->EndScene();

	m_D3DDevice->SetRenderTarget( 0 , m_BackBufferSurface );

	m_D3DDevice->Clear( 0 , NULL ,
						( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER ) ,
						D3DCOLOR_RGBA( 0 , 0 , 0 , 0 ),
						1.0f , 0 );

	m_D3DDevice->BeginScene();

	m_D3DDevice->SetRenderState( D3DRS_ALPHABLENDENABLE , FALSE );

	//--------- �S���2D�|���S���`�� ---------
	m_D3DDevice->SetFVF( FVF_VERTEX_2D );
	m_D3DDevice->SetTexture( 0 , m_BlurTexture1 );
	m_D3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP , 2 , &m_Vertex2D[ 0 ] , sizeof( VECTOR2D ) );

	m_D3DDevice->EndScene();

	m_D3DDevice->SetRenderState( D3DRS_ALPHABLENDENABLE , TRUE );

	LPDIRECT3DTEXTURE9 texture;
	texture = m_BlurTexture1;
	m_BlurTexture1 = m_BlurTexture2;
	m_BlurTexture2 = texture;

	LPDIRECT3DSURFACE9 surface;
	surface = m_BlurSurface1;
	m_BlurSurface1 = m_BlurSurface2;
	m_BlurSurface2 = surface;

	m_D3DDevice->Present( NULL , NULL , NULL , NULL );

}

//-----------------------------------------------------------------
//�|���S���`�揈��
//-----------------------------------------------------------------
LPDIRECT3DDEVICE9 CRenderer::GetDevice( void )
{
	return m_D3DDevice;
}