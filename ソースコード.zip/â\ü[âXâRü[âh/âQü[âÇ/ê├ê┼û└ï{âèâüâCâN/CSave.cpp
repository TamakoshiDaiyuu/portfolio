//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include <stdio.h>
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CSave.h"
#include "CInput.h"
#include "CSound_OpenAL.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�N���X�̐���
//-----------------------------------------------------------------
CSave::CSave()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CSave::~CSave()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
void CSave::Init( void )
{

}

//-----------------------------------------------------------------
//�t�@�C����ǂݍ��݁A�f�[�^���R�s�[������
//-----------------------------------------------------------------
void CSave::CreateMap( int cnt , WALL pos[ 3 ] , char *fileName )
{
	FILE *fp;

	float posNum;

	fp = fopen( fileName , "r" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	for( int a = 0 ; a < cnt ; a++ )
	{
		fscanf( fp , "P %d %f %f %f\n" , &a , &pos[ a ].pos.x , &pos[ a ].pos.y , &pos[ a ].pos.z );
		fscanf( fp , "R %d %f %f %f\n" , &a , &pos[ a ].rot.x , &pos[ a ].rot.y , &pos[ a ].rot.z );
	}

	rewind( fp );

	fclose( fp );
}

void CSave::ScoreObjectCreateMap( int cnt , MODEL pos[ 3 ] , char *fileName )
{
	FILE *fp;

	float posNum;

	fp = fopen( fileName , "r" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	for( int a = 0 ; a < cnt ; a++ )
	{
		fscanf( fp , "P %d %f %f %f\n" , &a , &pos[ a ].pos.x , &pos[ a ].pos.y , &pos[ a ].pos.z );
		fscanf( fp , "R %d %f %f %f\n" , &a , &pos[ a ].rot.x , &pos[ a ].rot.y , &pos[ a ].rot.z );
	}

	rewind( fp );

	fclose( fp );
}

D3DXVECTOR3 CSave::EnemyCreatePos( int cnt , char *fileName )
{
	FILE *fp;

	int a;

	float posNum;

	D3DXVECTOR3 EnemyPos[ 10 ];

	fp = fopen( fileName , "r" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	fscanf( fp , "P %d %f %f %f\n" , &a , &EnemyPos[ cnt ].x , &EnemyPos[ cnt ].y , &EnemyPos[ cnt ].z );
//	fscanf( fp , "R %d %f %f %f\n" , &a , &pos[ cnt ].x , &pos[ cnt ].y , &pos[ cnt ].z );

	rewind( fp );

	fclose( fp );

	return EnemyPos[ cnt ];
}

//-----------------------------------------------------------------
//�t�B�[���h�f�[�^��ۑ�
//-----------------------------------------------------------------
void CSave::SaveMap( int cnt , WALL pos[ 3 ] , char *fileName )
{
	FILE *fp;

	fp = fopen( fileName , "w+" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	for( int a = 0 ; a < cnt ; a++ )
	{
		fprintf( fp , "P %d %f %f %f\n" , a , pos[ a ].pos.x , pos[ a ].pos.y , pos[ a ].pos.z );
		fprintf( fp , "R %d %f %f %f\n" , a , pos[ a ].rot.x , pos[ a ].rot.y , pos[ a ].rot.z );
	}

	rewind( fp );

	fclose( fp );
}

void CSave::ScoreObjectSaveMap( int cnt , MODEL pos[ 3 ] , char *fileName )
{
	FILE *fp;

	fp = fopen( fileName , "w+" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	for( int a = 0 ; a < cnt ; a++ )
	{
		fprintf( fp , "P %d %f %f %f\n" , a , pos[ a ].pos.x , pos[ a ].pos.y , pos[ a ].pos.z );
		fprintf( fp , "R %d %f %f %f\n" , a , pos[ a ].rot.x , pos[ a ].rot.y , pos[ a ].rot.z );
	}

	rewind( fp );

	fclose( fp );
}

void CSave::SaveEnemyMap( int cnt , D3DXVECTOR3 pos[ 3 ] , D3DXVECTOR3 rot[ 3 ] , char *fileName )
{
	FILE *fp;

	fp = fopen( fileName , "w+" );

	if( fp == NULL )
	{
		exit( EXIT_FAILURE );
	}

	for( int a = 0 ; a < cnt ; a++ )
	{
		fprintf( fp , "P %d %f %f %f\n" , a , pos[ a ].x , pos[ a ].y , pos[ a ].z );
		fprintf( fp , "R %d %f %f %f\n" , a , rot[ a ].x , rot[ a ].y , rot[ a ].z );
	}

	rewind( fp );

	fclose( fp );
}


CSave *CSave::Create( void )
{
	CSave *createMap;

	createMap = new CSave;

	createMap->Init();

	return createMap;
}