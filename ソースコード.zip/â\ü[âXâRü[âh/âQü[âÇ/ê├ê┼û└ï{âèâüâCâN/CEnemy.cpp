//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CEnemy.h"
#include "CInput.h"
#include "CCamera.h"
#include "CSound_OpenAL.h"
#include "CWall.h"
#include "CPlayer.h"
#include "CSave.h"
//-----------------------------------------------------------------
//�f�t�@�C����`
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
//���f���̏��
MODEL m_enemy[ ENEMY_MAX ];

int b_MoveDirection[ ENEMY_MAX ];
//-----------------------------------------------------------------
//�N���X�̐���
//-----------------------------------------------------------------
CEnemy::CEnemy()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CEnemy::~CEnemy()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
void CEnemy::Init( void )
{
	CManager *manager;

	manager = GetManager();

	m_D3DDevice = NULL;

	rendererScneX = manager->GetRenderer();

	m_D3DDevice = rendererScneX->GetDevice();

	CSound_OpenAL::Init();

	//�N�I�[�^�j�I��������
	D3DXQuaternionIdentity( &m_Quatenion );

	m_DecisionMove = 0;

	m_TimeCnt = 0;

	b_MoveDirection[ 1 ] = 0;

	m_VtxaCnt = 0;

	//���f���\���̏�����
	for( int aCnt = 0 ; aCnt < ENEMY_MAX ; aCnt++ )
	{
		//�ϐ�������
		m_enemy[ aCnt ].pos = D3DXVECTOR3( -248.0f , 500.0f , -530.0f );
		m_enemy[ aCnt ].move = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );
		m_enemy[ aCnt ].rot = D3DXVECTOR3( 0.0f , -D3DX_PI , 0.0f );
		m_enemy[ aCnt ].scl = D3DXVECTOR3( 2.0f , 2.0f , 2.0f );

		//���f���̎g�p���
		m_enemy[ aCnt ].bUse = true;
		//�W�����v�̎g�p���
		m_enemy[ aCnt ].bJump = false;
		//���f�����ړ����
		m_enemy[ aCnt ].bUseMove = false;
		m_EnemyTimeCnt[ aCnt ] = 100;
	}

	m_enemy[ 1 ].pos = D3DXVECTOR3( 104.0f , 500.0f , -798.0f );
	m_enemy[ 1 ].rot = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );

	//�}�e���A����񏉊���
	D3DXLoadMeshFromX( "data/MODEL/eye001.x" ,
						D3DXMESH_SYSTEMMEM ,
						m_D3DDevice ,
						NULL ,
						&m_BuffMatModel ,
						NULL ,
						&m_numMatModel ,
						&m_MeshModel );

}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CEnemy::Uninit( void )
{

	CSound_OpenAL::Uninit();

	if( &m_MeshModel != NULL )
	{
		//�e�N�X�`���̏I������
		m_MeshModel->Release();
		m_MeshModel = NULL;
	}

	if( &m_BuffMatModel != NULL )
	{
		//�e�N�X�`���̏I������
		m_BuffMatModel->Release();
		m_BuffMatModel = NULL;
	}
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CEnemy::Update( void )
{

	//�N�I�[�^�j�I���Ɏg���ϐ�
	D3DXVECTOR3 axis;
	D3DXQUATERNION quat;

	// ---�N���X�̎󂯎��---
	CManager *manager = GetManager();
	CInput *Input = manager->GetInput();
	CSound_OpenAL *soundAL = manager->GetSoundAL();
	CCamera *camera = manager->GetCamera();
	CWall *wall = manager->GetWall();
	CPlayer *player = manager->GetPlayer();
	CSave *save = manager->GetSave();

	if( Input->GetKeyboardPress( DIK_C ) )
	{
		m_enemy[ 0 ].pos = save->EnemyCreatePos( 1 , "EnemyMaping.txt" );	// ���_�̕ۑ�
	}
	if( Input->GetKeyboardPress( DIK_SPACE ) )
	{
		save->SaveEnemyMap( ENEMY_MAX , &m_enemy[ 0 ].pos , &m_enemy[ 0 ].rot , "EnemyMaping.txt" );	// ���_�̕ۑ�
	}

	// ���݂̎w�肵�����_��ύX
	if( Input->GetKeyboardTrigger( DIK_I ) )
	{
		m_VtxaCnt++;
	}
	if( Input->GetKeyboardTrigger( DIK_K ) )
	{
		m_VtxaCnt--;
	}

	m_TimeCnt++;

	for( int aCnt = 0 ; aCnt < ENEMY_MAX ; aCnt++ )
	{
		//�ǂ̂����蔻��
		m_enemy[ aCnt ].rot.y = wall->MoveCollisionWall( m_enemy[ aCnt ].pos , m_enemy[ aCnt ].rot.y );

		m_enemy[ aCnt ].pos = wall->CollisionWall( m_enemy[ aCnt ].pos );

		/*if( m_TimeCnt > m_EnemyTimeCnt[ aCnt ] )
		{*/
			//m_enemy[ 0 ].pos = player->GetBreadCrumb( m_enemy[ 0 ].pos );
		//}

		if( m_enemy[ aCnt ].rot.y == -D3DX_PI )
		{
			m_enemy[ aCnt ].pos.x += 0.5f;
		}
		else if( m_enemy[ aCnt ].rot.y == 0 )
		{
			m_enemy[ aCnt ].pos.x -= 0.5f;
		}
		else if( m_enemy[ aCnt ].rot.y == D3DX_PI/2 )
		{
			m_enemy[ aCnt ].pos.z +=  0.5f;
		}
		else if( m_enemy[ aCnt ].rot.y == -D3DX_PI/2 )
		{
			m_enemy[ aCnt ].pos.z -=  0.5f;
		}
	}
	//CSound_OpenAL::SetPosition( 2 , m_enemy[ 0 ].pos.x , m_enemy[ 0 ].pos.y , m_enemy[ 0 ].pos.z );
	//CSound_OpenAL::Play( 2 );

	//-------------------------------------------
	//�N�I�[�^�j�I����]����
	//-------------------------------------------

	//-------------------------------------------
	//���̂����蔻��
	//-------------------------------------------

	//-------------------------------------------
	//---�ړ�����---�ЂȌ^�Ȃ�����Ă�����
	//-------------------------------------------
	if( Input->GetKeyboardPress( DIK_W ) )
	{
		m_enemy[ m_VtxaCnt ].pos.z += 2;

		//CSound_OpenAL::Play( 2 );	// �T�E���h�쐬
	}
	if( Input->GetKeyboardPress( DIK_S ) )
	{
		m_enemy[ m_VtxaCnt ].pos.z -= 2;
		//CSound_OpenAL::Play( 2 );	// �T�E���h�쐬
	}
	if( Input->GetKeyboardPress( DIK_A ) )
	{
		m_enemy[ m_VtxaCnt ].pos.x -= 2;

		//CSound_OpenAL::Play( 2 );	// �T�E���h�쐬

	}
	if( Input->GetKeyboardPress( DIK_D ) )
	{
		m_enemy[ m_VtxaCnt ].pos.x += 2;

		//CSound_OpenAL::Play( 2 );	// �T�E���h�쐬

	}

	///*if( m_enemy[ 0 ].pos.z <= -300 && m_enemy[ 0 ].pos.z >= -320 )
	//{
	//	m_DecisionMove = 1;
	//}

	//if( m_DecisionMove == 0 )
	//{
	//	m_enemy[ 0 ].move.z = -1;
	//}

	//if( m_DecisionMove == 1 )
	//{
	//	m_enemy[ 0 ].move.z = +1;
	//}*/

	//-------------------------------------------
	//���f�����̍X�V
	//-------------------------------------------
}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CEnemy::Draw( void )
{
	//�ʒu���
	D3DXMATRIX mtxScl[ ENEMY_MAX ] , mtxRot[ ENEMY_MAX ] , mtxTrans[ ENEMY_MAX ];

	D3DXMATERIAL *pMat;

	//���f���̏��ێ�����ϐ�
	D3DMATERIAL9 matDef;

	CManager *manager;

	manager = GetManager();

	rendererScneX = manager->GetRenderer();

	m_D3DDevice = rendererScneX->GetDevice();

	//-------------------------------------------
	//3D�̕`��ݒ�
	//-------------------------------------------

	//���f���\����
	for( int aCnt = 0 ; aCnt < ENEMY_MAX - 1 ; aCnt++ )
	{
		//���[���h�}�g���b�N�X�̏�����
		D3DXMatrixIdentity( &m_mtxWorldModel[ aCnt ] );

		if( m_enemy[ aCnt ].bUse == true )
		{
			//�X�P�[���𔽉f
			D3DXMatrixScaling( &mtxScl[ aCnt ] , m_enemy[ aCnt ].scl.x , m_enemy[ aCnt ].scl.y , m_enemy[ aCnt ].scl.z );

			D3DXMatrixMultiply( &m_mtxWorldModel[ aCnt ] , &m_mtxWorldModel[ aCnt ], &mtxScl[ aCnt ] );

			D3DXMatrixRotationYawPitchRoll( &mtxRot[ aCnt ] , m_enemy[ aCnt ].rot.y , m_enemy[ aCnt ].rot.x , m_enemy[ aCnt ].rot.z );
			
			//�N�H�[�e�[�V�����̉�]�}�g���b�N�X
			//D3DXMatrixRotationQuaternion( &mtxRot[ aCnt ] , &m_Quatenion );

			//��]
			D3DXMatrixMultiply( &m_mtxWorldModel[ aCnt ] , &m_mtxWorldModel[ aCnt ] , &mtxRot[ aCnt ] );

			D3DXMatrixTranslation( &mtxTrans[ aCnt ] , m_enemy[ aCnt ].pos.x , m_enemy[ aCnt ].pos.y , m_enemy[ aCnt ].pos.z );

			//�ʒu�𔽉f
			D3DXMatrixMultiply( &m_mtxWorldModel[ aCnt ] , &m_mtxWorldModel[ aCnt ], &mtxTrans[ aCnt ] );

			m_D3DDevice->SetTransform( D3DTS_WORLD , &m_mtxWorldModel[ aCnt ] );

			//-------------------------------------------

			//���݂̃}�e���A�����̕ێ�
			m_D3DDevice->GetMaterial( &matDef );

			//�ϊ�
			pMat = ( D3DXMATERIAL * )m_BuffMatModel->GetBufferPointer();

			for( int nCntMat = 0 ; nCntMat < ( int )m_numMatModel ; nCntMat++ )
			{
				m_D3DDevice->SetMaterial( &pMat[ nCntMat ].MatD3D );

				//�e�N�X�`���̐ݒ�
				m_D3DDevice->SetTexture( 0 , NULL );

				//���b�V���`��
				m_MeshModel->DrawSubset( nCntMat );

			}

			//�}�e���A��������
			m_D3DDevice->SetMaterial( &matDef );
		}
	}
}

CEnemy *CEnemy::Create( void )
{
	CEnemy *sceneX;

	sceneX = new CEnemy;

	sceneX->Init();

	return sceneX;

}

//-----------------------------------------------------------------
//GET����
//-----------------------------------------------------------------
D3DXVECTOR3 CEnemy::GetPosition( D3DXVECTOR3 pos )
{
	pos = m_enemy[ 0 ].pos;

	return pos;
}

//-----------------------------------------------------------------
//HIT����
//-----------------------------------------------------------------
bool CEnemy::HitEnemy( D3DXVECTOR3 pos , bool hit , float TargetRenge )
{

	for( int aCnt = 0 ; aCnt < ENEMY_MAX - 1 ; aCnt++ )
	{
		if( m_enemy[ aCnt ].pos.x + TargetRenge > pos.x && m_enemy[ aCnt ].pos.x - TargetRenge < pos.x &&
			m_enemy[ aCnt ].pos.z + TargetRenge > pos.z && m_enemy[ aCnt ].pos.z - TargetRenge < pos.z )
		{
			hit = true;
			break;
		}
		else
		{
			hit = false;
		}
	}

	return hit;
}