//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CFade.h"
#include "CInput.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
//�t�F�[�h�̏��
FADE g_Fade;

MODE g_modeNext;

int fadeCnt;
//-----------------------------------------------------------------
// �N���X�̐���
//-----------------------------------------------------------------
CFade::CFade()
{

}

//-----------------------------------------------------------------
// �N���X�̔j��
//-----------------------------------------------------------------
CFade::~CFade()
{

}

//-----------------------------------------------------------------
// ����������
//-----------------------------------------------------------------
void CFade::Init( void )
{
	CManager *maneger = GetManager();

	m_D3DDevice = NULL;

	//�e�N�X�`���ւ̃|�C���^�[
	m_TexturePolygon = NULL;

	renderer = maneger->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	m_ColorFade = D3DXCOLOR( 0.0f , 0.0f , 0.0f , 1.0f );

	g_Fade = FADE_IN;

	g_modeNext = MODE_TITLE;

	fadeCnt = 0;

	//�e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile( m_D3DDevice , "data/TEXTURE/fade.jpg" , &m_TexturePolygon );

	//�|���S���̍��W
	m_Polygon2D[ 0 ].pos = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );
	m_Polygon2D[ 1 ].pos = D3DXVECTOR3( SCREEN_WIDTH , 0.0f , 0.0f );
	m_Polygon2D[ 2 ].pos = D3DXVECTOR3( 0.0f , SCREEN_HEIGHT , 0.0f );
	m_Polygon2D[ 3 ].pos = D3DXVECTOR3( SCREEN_WIDTH , SCREEN_HEIGHT , 0.0f );

	m_Polygon2D[ 0 ].rhw = 1.0f;
	m_Polygon2D[ 1 ].rhw = 1.0f;
	m_Polygon2D[ 2 ].rhw = 1.0f;
	m_Polygon2D[ 3 ].rhw = 1.0f;

	m_Polygon2D[ 0 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_Polygon2D[ 1 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_Polygon2D[ 2 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_Polygon2D[ 3 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );

	//�e�N�X�`���̍��W
	m_Polygon2D[ 0 ].tex = D3DXVECTOR2( 0.0f , 0.0f );
	m_Polygon2D[ 1 ].tex = D3DXVECTOR2( 1.0f , 0.0f );
	m_Polygon2D[ 2 ].tex = D3DXVECTOR2( 0.0f , 1.0f );
	m_Polygon2D[ 3 ].tex = D3DXVECTOR2( 1.0f , 1.0f );

}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CFade::Uninit( void )
{
	if( m_TexturePolygon != NULL )
	{
		//�e�N�X�`���̏I������
		m_TexturePolygon->Release();
		m_TexturePolygon = NULL;
	}

}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CFade::Update( void )
{
	CManager *manager = GetManager();

	CInput *Input = manager->GetInput();

	if( g_Fade == FADE_IN )
	{
		m_ColorFade.a -= 0.01f;

		if( m_ColorFade.a < 0 )
		{
			g_Fade = FADE_NONE;
		}

	}
	else if( g_Fade == FADE_OUT )
	{
		m_ColorFade.a += 0.1f;

		if( m_ColorFade.a > 1.0f )
		{
			manager->SetMode( g_modeNext );

			g_Fade = FADE_IN;
		}
	}

	m_Polygon2D[ 0 ].col = D3DXCOLOR( m_ColorFade.r , m_ColorFade.g , m_ColorFade.b , m_ColorFade.a );
	m_Polygon2D[ 1 ].col = D3DXCOLOR( m_ColorFade.r , m_ColorFade.g , m_ColorFade.b , m_ColorFade.a );
	m_Polygon2D[ 2 ].col = D3DXCOLOR( m_ColorFade.r , m_ColorFade.g , m_ColorFade.b , m_ColorFade.a );
	m_Polygon2D[ 3 ].col = D3DXCOLOR( m_ColorFade.r , m_ColorFade.g , m_ColorFade.b , m_ColorFade.a );

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CFade::Draw( void )
{
	CManager *manager = GetManager();

	CRenderer *renderer = manager->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	//�t�H�[�}�b�g�ݒ�
	m_D3DDevice->SetFVF( FVF_VERTEX_2D );

	//�e�N�X�`���̐ݒ�
	m_D3DDevice->SetTexture( 0 , m_TexturePolygon );

	//�|���S���̕`��
	m_D3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP , 2 , &m_Polygon2D[ 0 ] , sizeof( VECTOR2D ) );
}

CFade *CFade::Create( void )
{
	CFade *fade;

	fade = new CFade;

	fade->Init();

	return fade;
}

//-----------------------------------------------------------------
//�t�F�[�h���Z�b�g����֐�
//-----------------------------------------------------------------
void CFade::SetFade ( FADE fade , MODE modeNext )
{
	g_Fade = fade;

	g_modeNext = modeNext;
}

//-----------------------------------------------------------------
//�t�F�[�h�̏�Ԏ擾�֐�
//-----------------------------------------------------------------
FADE CFade::GetFade ( void )
{
	return g_Fade;
}