/*-----------------------------------------------------------------*/
/*制作者：玉越大雄
/*制作日：2020/1.15
/*フルスクラッチ
/*メモ
/*filter filterImage imgの要素をあらかじめ設定しておくこと*/
/*後々ここで宣言して自動生成するようにすることが課題
/*背景のフィルターが移動時に不安定なので改善案を考える
/*使い方：クラス名にlightBoxと記載すること*/
/*-----------------------------------------------------------------*/
var filter = document.getElementById("filter"); //背景を黒くするフィルター
var filterImage = document.getElementById("filterImage");
var target = document.querySelectorAll(".lightBox");
var targetImage; //子要素はhtmlCollectionとして取得
var windowY = window.pageYOffset; //ウィンドウのY座標
var windowH = window.innerHeight; //ウィンドウの高さ

window.onscroll = function(){
  filter.style.top = windowY;
}

/*フェードイン エラーはdom制作前に起動しているために発生している？
--------------------------------------*/
function onLightBox(key_){
  filter.style.opacity = "1";
  filter.style.backgroundColor = "rgba(0,0,0, 0.5)";//子要素も半透明にならないよう、rgbaで表現
  filter.style.zIndex = "1";
  targetImage = target[key_].children;
  //backgroundImage変更
  filterImage.style.backgroundImage = "url(" + targetImage[0].children[0].getAttribute("src") + ")" ;
}
for(var key in target){
  (function(key_){
    target[key_].addEventListener("click" , function(){onLightBox(key_)} , false );
   }(key));
}
/*フェードアウト処理
--------------------------------------*/
function fadeOut(){
  filter.style.opacity = "0";
  filter.style.backgroundColor = "rgba(0,0,0, 0.5)";
  filter.style.zIndex = "-1";
}