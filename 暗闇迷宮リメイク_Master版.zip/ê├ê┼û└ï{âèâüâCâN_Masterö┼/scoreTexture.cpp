//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "scene2D.h"
#include "scoreTexture.h"
#include "CInput.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Rnderer�N���X�̐���
//-----------------------------------------------------------------
scoreTexture::scoreTexture()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
scoreTexture::~scoreTexture()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
void scoreTexture::Init( void )
{
	CManager *maneger = GetManager();

	m_D3DDevice = NULL;

	//�e�N�X�`���ւ̃|�C���^�[
	m_TexturePolygon = NULL;

	renderer = maneger->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	//�e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile( m_D3DDevice , "data/TEXTURE/score_text001.png" , &m_TexturePolygon );

	float PosX = 30.0f;
	float PosY = 30.0f;
	float width = 110.0f;
	float height = 110.0f;

	//�|���S���̍��W
	m_ScneVertex2D[ 0 ].pos = D3DXVECTOR3( PosX , PosY , 0.0f );
	m_ScneVertex2D[ 1 ].pos = D3DXVECTOR3( PosX + width , PosY , 0.0f );
	m_ScneVertex2D[ 2 ].pos = D3DXVECTOR3( PosX , PosY + height , 0.0f );
	m_ScneVertex2D[ 3 ].pos = D3DXVECTOR3( PosX + width , PosY + height , 0.0f );

	m_ScneVertex2D[ 0 ].rhw = 1.0f;
	m_ScneVertex2D[ 1 ].rhw = 1.0f;
	m_ScneVertex2D[ 2 ].rhw = 1.0f;
	m_ScneVertex2D[ 3 ].rhw = 1.0f;

	m_ScneVertex2D[ 0 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 1 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 2 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );
	m_ScneVertex2D[ 3 ].col = D3DCOLOR_RGBA( 255 , 255 , 255 , 255 );

	//�e�N�X�`���̍��W
	m_ScneVertex2D[ 0 ].tex = D3DXVECTOR2( 0.0f , 0.0f );
	m_ScneVertex2D[ 1 ].tex = D3DXVECTOR2( 1.0f , 0.0f );
	m_ScneVertex2D[ 2 ].tex = D3DXVECTOR2( 0.0f , 1.0f );
	m_ScneVertex2D[ 3 ].tex = D3DXVECTOR2( 1.0f , 1.0f );

}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void scoreTexture::Uninit( void )
{
	if( m_TexturePolygon != NULL )
	{
		//�e�N�X�`���̏I������
		m_TexturePolygon->Release();
		m_TexturePolygon = NULL;
	}

}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void scoreTexture::Update( void )
{
	CManager *manager = GetManager();

	CInput *Input = manager->GetInput();

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void scoreTexture::Draw( void )
{
	CManager *manager = GetManager();

	CRenderer *renderer = manager->GetRenderer();

	m_D3DDevice = renderer->GetDevice();

	//�t�H�[�}�b�g�ݒ�
	m_D3DDevice->SetFVF( FVF_VERTEX_2D );

	//�e�N�X�`���̐ݒ�
	m_D3DDevice->SetTexture( 0 , m_TexturePolygon );

	//�|���S���̕`��
	m_D3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP , 2 , &m_ScneVertex2D[ 0 ] , sizeof( TYPE_SCORETEX_VERTEX_2D ) );
}

scoreTexture *scoreTexture::Create( void )
{
	scoreTexture *scene2D;

	scene2D = new scoreTexture;

	scene2D->Init();

	return scene2D;
}