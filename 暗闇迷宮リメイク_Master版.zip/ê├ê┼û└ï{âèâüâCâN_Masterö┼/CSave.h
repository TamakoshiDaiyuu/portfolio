//-----------------------------------------------------------------
//GM31 renderer
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------
//-----------------------------------------------------------------
//�C���N���[�h�K�[�h
//-----------------------------------------------------------------
#ifndef _CreateMap_H_
#define _CreateMap_H_

//-------------------------------------------------------------------
//�C���N���[�h
//-------------------------------------------------------------------
#include "d3dx9.h"
#include "scene.h"
#include "alut.h"
#include "CWall.h"
#include "CScoreItem.h"
//-------------------------------------------------------------------
//���C�u�����̃����N
//-------------------------------------------------------------------
#pragma comment(lib,"OpenAL32.lib")
#pragma comment(lib,"alut.lib")

//-------------------------------------------------------------------
//�}�N����`
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�\����
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�N���X
//-------------------------------------------------------------------
class CSave
{
	private:

	public:

		CSave();
		~CSave();

		void Init( void );
		void CreateMap( int cnt , WALL pos[ 3 ] , char *fileName );
		void SaveMap( int cnt , WALL pos[ 3 ] , char *fileName );
		void SaveEnemyMap( int cnt , D3DXVECTOR3 pos[ 3 ] , D3DXVECTOR3 rot[ 3 ] , char *fileName );

		void ScoreObjectSaveMap( int cnt , MODEL pos[ 4 ] , char *fileName );
		void ScoreObjectCreateMap( int cnt , MODEL pos[ 4 ] , char *fileName );
		D3DXVECTOR3 EnemyCreatePos( int cnt , char *fileName );

		static CSave *CSave::Create( void );

};

#endif