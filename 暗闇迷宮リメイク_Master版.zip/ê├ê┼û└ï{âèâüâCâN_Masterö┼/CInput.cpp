//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CInput.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Rnderer�N���X�̐���
//-----------------------------------------------------------------
CInput::CInput()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CInput::~CInput()
{

}

//-----------------------------------------------------------------
//Input����������
//-----------------------------------------------------------------
HRESULT CInput::InitInput ( HINSTANCE hInstance , HWND hWnd )
{
	m_Input = NULL;

	if( m_Input == NULL )
	{
		//DirectInput8�I�u�W�F�N�g����
		if( FAILED( DirectInput8Create( hInstance , DIRECTINPUT_VERSION , IID_IDirectInput8 , ( void** )&m_Input , NULL ) ) )
		{
			return E_FAIL;
		}
	}
	return S_OK;
}

//-----------------------------------------------------------------
//Keyboard����������
//-----------------------------------------------------------------
HRESULT CInput::InitKeyboard ( HINSTANCE hInstance , HWND hWnd )
{
	if( FAILED( InitInput( hInstance , hWnd ) ) )
	{
		return E_FAIL;
	}

	if( FAILED( m_Input->CreateDevice( GUID_SysKeyboard , &m_DevKeyboard , NULL ) ) )
	{
		return E_FAIL;
	}

	//�f�[�^�t�H�[�}�b�g�̐ݒ�
	if( FAILED( m_DevKeyboard->SetDataFormat( &c_dfDIKeyboard ) ) )
	{
		return E_FAIL;
	}

	//�������[�h�̐ݒ�
	if( FAILED( m_DevKeyboard->SetCooperativeLevel( hWnd , ( DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ) ) ) )
	{
		return E_FAIL;
	}

	for( int a = 0 ; a < 256 ; a++ )
	{
		m_aKeyState[ a ] = 0;

		m_aStateTrigger[ a ] = 0;
		
		m_aStateRelease[ a ] = 0;
	}

	//�L�[�{�[�h���擾�̃A�N�Z�X�����擾
	m_DevKeyboard->Acquire();
}

//-----------------------------------------------------------------
//Keyboard����������
//-----------------------------------------------------------------
HRESULT CInput::InitMouse ( HINSTANCE hInstance , HWND hWnd )
{
	
	if( FAILED( InitInput( hInstance , hWnd ) ) )
	{
		return E_FAIL;
	}

	if( FAILED( m_Input->CreateDevice( GUID_SysMouse , &m_DevMouse , NULL ) ) )
	{
		return E_FAIL;
	}

	//�f�[�^�t�H�[�}�b�g�̐ݒ�
	if( FAILED( m_DevMouse->SetDataFormat( &c_dfDIMouse ) ) )
	{
		return E_FAIL;
	}

	//�������[�h�̐ݒ�
	if( FAILED( m_DevMouse->SetCooperativeLevel( hWnd , ( DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ) ) ) )
	{
		return E_FAIL;
	}

	for( int a = 0 ; a < 4 ; a++ )
	{
		m_aStateMouse[ a ] = 0;
	}

	//�L�[�{�[�h���擾�̃A�N�Z�X�����擾
	m_DevMouse->Acquire();
}

//-----------------------------------------------------------------
//Input�I������
//-----------------------------------------------------------------
void CInput::UninitInput( void )
{
	if( m_Input != NULL )
	{
		m_Input -> Release();
		m_Input = NULL;
	}
}

//-----------------------------------------------------------------
//Keyboard�I������
//-----------------------------------------------------------------
void CInput::UninitKeyboard( void )
{
	if( m_DevKeyboard != NULL )
	{
		m_DevKeyboard->Unacquire();
		m_DevKeyboard->Release();
		m_DevKeyboard = NULL;
	}

	//�{�̂̉��
	UninitInput();
}

//-----------------------------------------------------------------
//Mouse�I������
//-----------------------------------------------------------------
void CInput::UninitMouse( void )
{
	if( m_DevMouse != NULL )
	{
		m_DevMouse->Unacquire();
		m_DevMouse->Release();
		m_DevMouse = NULL;
	}

	//�{�̂̉��
	UninitInput();
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CInput::UpdateKeyboard( void )
{
	BYTE aKeyState[ 256 ];

	if( SUCCEEDED( m_DevKeyboard->GetDeviceState( sizeof( aKeyState ) , &aKeyState[ 0 ] ) ) )
	{
		for( int nCntKey = 0 ; nCntKey < 256 ; nCntKey++ )
		{
			//Trigger
			m_aStateTrigger[ nCntKey ] = aKeyState[ nCntKey ] & ~m_aKeyState[ nCntKey ];
			//Release
			m_aStateRelease[ nCntKey ] = aKeyState[ nCntKey ] ^ m_aKeyState[ nCntKey ];
			//Repeat

			//Press
			m_aKeyState[ nCntKey ] = aKeyState[ nCntKey ];
		}
	}
	else
	{
		m_DevKeyboard->Acquire();
	}
}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CInput::UpdateMouse( void )
{
	if( SUCCEEDED( m_DevMouse->GetDeviceState( sizeof( MouseState ) , &MouseState ) ) )
	{

	}
	else
	{
		m_DevMouse->Acquire();
	}
}


//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetKeyboardPress( int nKey )
{
	return ( m_aKeyState[ nKey ]&0x80 ) ? true : false;
}

//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetKeyboardRelease( int nKey )
{
	return ( m_aStateRelease[ nKey ]&0x80 ) ? true : false;
}

//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetKeyboardTrigger( int nKey )
{
	return ( m_aStateTrigger[ nKey ]&0x80 ) ? true : false;
}

//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetMouseRgbButtons( int Mouse )
{
	return ( MouseState.rgbButtons[Mouse]&0x80 ) ? true : false;
}
//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetMouseLeft( void )
{
	return ( MouseState.lX < 0 ) ? true : false;
}
//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetMouseRight( void )
{
	return ( MouseState.lX > 0 ) ? true : false;
}
//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetMouseUp( void )
{
	return ( MouseState.lY > 0 ) ? true : false;
}
//-----------------------------------------------------------------
//���͏���
//-----------------------------------------------------------------
bool CInput::GetMouseDown( void )
{
	return ( MouseState.lY < 0 ) ? true : false;
}