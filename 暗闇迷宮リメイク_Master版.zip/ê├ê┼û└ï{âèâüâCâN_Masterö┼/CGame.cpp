//-----------------------------------------------------------------
// GM31
// AT13B284 26 �ʉz��Y
// �쐬��
// �C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CMeshField.h"
#include "CGame.h"
#include "CInput.h"
#include "CSound_OpenAL.h"
#include "CCamera.h"
#include "CSkyBox.h"
#include "CPlayer.h"
#include "CEnemy.h"
#include "CScore.h"
#include "CBillBord.h"
#include "scoreTexture.h"
#include "CScoreItem.h"
#include "CWall.h"
#include "CSave.h"
#include "CFade.h"
#include "CLight.h"
//-----------------------------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// �}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------------------------
bool m_bUseBlur;
//-----------------------------------------------------------------
// �N���X�̐���
//-----------------------------------------------------------------
CGame::CGame()
{

}

//-----------------------------------------------------------------
// �N���X�̔j��
//-----------------------------------------------------------------
CGame::~CGame()
{

}

//-----------------------------------------------------------------
// ����������
//-----------------------------------------------------------------
void CGame::Init( void )
{
	m_bUseBlur = false;

	CManager *manager	= GetManager();
	CRenderer *renderer = manager->GetRenderer();
	CSave *save = manager->GetSave();
	CLight *light = manager->GetLight();

	//�T�E���h�쐬
	CSound_OpenAL::Init();
	CSound_OpenAL::Play( 0 );

	// ---�N���G�C�g�֐�---
	//CSkyBox::Create();				// �X�J�C�{�b�N�X(�o�O���Ă�H)
	CMeshField::Create();
	CWall::Create();
	CScoreItem::Create();
	CPlayer::Create();
	CEnemy::Create();

	// ---�QD�I�u�W�F�N�g---
	CScore::Create();
	scoreTexture::Create();

	CFade::Create();
	//m_Renderer->DrawFog();
}

//-----------------------------------------------------------------
// �I������
//-----------------------------------------------------------------
void CGame::Uninit( void )
{
	CScene::UninitAll();
}

//-----------------------------------------------------------------
// �X�V����
//-----------------------------------------------------------------
void CGame::Update( void )
{
	int scoreCnt = 0;

	bool gameOver = false;

	D3DXVECTOR3 playerPos;

	D3DXVECTOR3 pos;

	//�t�F�[�h�Ɏg���ϐ�
	int fadeMode;

	CManager *manager	= GetManager();
	CInput *Input 		= manager->GetInput();
	CRenderer *renderer = manager->GetRenderer();
	CScore *score		= manager->GetScore();
	CPlayer *player		= manager->GetPlayer();
	CEnemy *enemy		= manager->GetEnemy();
	CFade *fade			= manager->GetFade();

	playerPos = player->GetPosition( playerPos );

	m_bUseBlur = enemy->HitEnemy( playerPos , m_bUseBlur , 300.0f );

	gameOver = enemy->HitEnemy( playerPos , gameOver , 50.0f );

	scoreCnt = score->GetScore( scoreCnt );

	fadeMode = fade->GetFade();

	//��ʑJ��
	//�Q�[���N���A�[��ʈڍs
	if( fadeMode == FADE_NONE )
	{
		//��ʑJ��
		if( Input->GetKeyboardTrigger( DIK_RETURN ) )
		{
				fade->SetFade( FADE_OUT , MODE_TITLE );
		}

		//�Q�[���I�[�o�[����
		if( gameOver == true )
		{
			fade->SetFade( FADE_OUT , MODE_RESULT );
		}

		//��ʑJ��
		if( scoreCnt == 0 )
		{
			fade->SetFade( FADE_OUT , MODE_TITLE );
		}
	}

	CScene::UpdateAll();
}

//-----------------------------------------------------------------
// �`�揈��
//-----------------------------------------------------------------
void CGame::Draw( void )
{
	CManager *manager = GetManager();
	CCamera *camera =manager->GetCamera();
	CRenderer *renderer = manager->GetRenderer();

	if( m_bUseBlur == true )
	{
		renderer->DrawBlurBegin();

		camera->Draw();
		//SCENE�֘A�`��
		CScene::DrawAll();

		renderer->DrawBlurEnd();
	}
	else
	{
		renderer->DrawBegin();

		camera->Draw();
		//SCENE�֘A�`��
		CScene::DrawAll();

		renderer->DrawEnd();
	}
}