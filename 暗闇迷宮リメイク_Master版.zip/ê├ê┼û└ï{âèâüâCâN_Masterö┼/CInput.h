//-----------------------------------------------------------------
//GM31 renderer
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------
//-----------------------------------------------------------------
//�C���N���[�h�K�[�h
//-----------------------------------------------------------------
#ifndef _CINPUT_H_
#define _CINPUT_H_

//-------------------------------------------------------------------
//�C���N���[�h
//-------------------------------------------------------------------
#include "d3dx9.h"

//-------------------------------------------------------------------
//���C�u�����̃����N
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�}�N����`
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�\����
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//�N���X
//-------------------------------------------------------------------
class CInput
{
	private:

	LPDIRECTINPUT8 m_Input;
	LPDIRECTINPUTDEVICE8 m_DevKeyboard;

	LPDIRECTINPUTDEVICE8 m_DevMouse;

	BYTE m_aKeyState[ 256 ];
	BYTE m_aStateTrigger[ 256 ];
	BYTE m_aStateRelease[ 256 ];

	// �}�E�X�̏�Ԏ擾(pDIDMouse�͏������ς݂̃}�E�X�̃f�o�C�X�I�u�W�F�N�g)
	DIMOUSESTATE MouseState; // �}�E�X�̏�Ԃ��i�[����\���̕ϐ�
	BYTE m_aStateMouse[ 256 ];

	public:

		CInput();
		~CInput();

		HRESULT InitInput( HINSTANCE hInstance , HWND hWnd );
		void UninitInput( void );
		void UpdateInput( void );

		HRESULT InitKeyboard( HINSTANCE hInstance , HWND hWnd );
		void UninitKeyboard( void );
		void UpdateKeyboard( void );

		bool GetKeyboardPress( int nKey );
		bool GetKeyboardTrigger( int nKey );
		bool GetKeyboardRelease( int nKey );

		HRESULT InitMouse ( HINSTANCE hInstance , HWND hWnd );
		void UninitMouse( void );
		void UpdateMouse( void );

		bool GetMouseRgbButtons( int Mouse );
		bool GetMouseLeft( void );
		bool GetMouseRight( void );
		bool GetMouseUp( void );
		bool GetMouseDown( void );
};

#endif