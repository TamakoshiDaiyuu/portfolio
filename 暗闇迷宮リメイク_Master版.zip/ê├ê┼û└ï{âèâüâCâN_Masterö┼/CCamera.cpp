//-----------------------------------------------------------------
//GM31 SCENE�`��
//AT13B284 26 �ʉz��Y
//�쐬��2016/04/18
//�C����
//-------------------------------------------------------------------

//-----------------------------------------------------------------
//include�錾
//-----------------------------------------------------------------
#include "main.h"
#include "CManager.h"
#include "renderer.h"
#include "CCamera.h"
#include "CInput.h"
#include "CPlayer.h"
#include "CScoreItem.h"
#include "CWall.h"
#include "CSound_OpenAL.h"
//-----------------------------------------------------------------
//�v���g�^�C�v�錾
//-----------------------------------------------------------------
#define CAMERA_RENGE 1.0f;

#define CAMERA_ROTATION_SPEED 0.2f;
//-----------------------------------------------------------------
//�}�N���錾
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//�O���[�o���ϐ�
//-----------------------------------------------------------------
//-----------------------------------------------------------------
// Rnderer�N���X�̐���
//-----------------------------------------------------------------
CCamera::CCamera()
{

}

//-----------------------------------------------------------------
// Rnderer�N���X�̔j��
//-----------------------------------------------------------------
CCamera::~CCamera()
{

}

//-----------------------------------------------------------------
// Renderer�̏���������
//-----------------------------------------------------------------
void CCamera::Init( void )
{
	m_D3DDevice = NULL;

	//�J�����̈ʒu
	m_Camera.posV = D3DXVECTOR3( 0.0 , 520.0 , -150.0 );

	m_Camera.posR = D3DXVECTOR3( 0.0 , 0.0 , 0.0 );

	//������x�N�g��
	m_Camera.VecU = D3DXVECTOR3( 0.0f , 1.0f , 0.0f );

	//��]
	m_Camera.rot = D3DXVECTOR3( 0.0f , 0.0f , 0.0f );

	//�J�����ƒ����_�̋����A�p�x�ݒ�
	m_Camera.fDistance = sqrtf( m_Camera.posV.x * m_Camera.posV.x + m_Camera.posV.y * m_Camera.posV.y );
}

//-----------------------------------------------------------------
//�I������
//-----------------------------------------------------------------
void CCamera::Uninit( void )
{

}

//-----------------------------------------------------------------
//�X�V����
//-----------------------------------------------------------------
void CCamera::Update( void )
{
	D3DXVECTOR3 modelRot;

	CManager *manager = GetManager();
	CInput *Input = manager->GetInput();
	CPlayer *player = manager->GetPlayer();
	CScoreItem *ScoreItem = manager->GetScoreItem();
	CWall *wall = manager->GetWall();

	//--------- �������� ---------
	//--- �v���C���[�ƈʒu�𓯊� ---
	m_Camera.posR = player->GetPosition( m_Camera.posR );
	m_Camera.posV = player->GetPosition( m_Camera.posV );
	modelRot = player->GetRotation( modelRot );

	//-----------------------------------------------------------------
	//�J�����̒����_�̋����ݒ�
	m_Camera.posV.x = m_Camera.posR.x - sinf( m_Camera.rot.y ) * CAMERA_RENGE;

	m_Camera.posV.z = m_Camera.posR.z - cosf( m_Camera.rot.y ) * CAMERA_RENGE;

	m_Camera.posV.x = m_Camera.posR.x + sinf( m_Camera.rot.y ) * CAMERA_RENGE;

	m_Camera.posV.z = m_Camera.posR.z + cosf( m_Camera.rot.y ) * CAMERA_RENGE;

	//-----------------------------------------------------------------

	//���K���i��]�l�𐳂����l�ɕϊ��j
	if( m_Camera.targetRot.y > D3DX_PI )
	{
		m_Camera.targetRot.y = m_Camera.targetRot.y - ( D3DX_PI * 2 );
	}
	else if( m_Camera.targetRot.y < -D3DX_PI )
	{
		m_Camera.targetRot.y = m_Camera.targetRot.y + ( D3DX_PI * 2 );
	}

	//-----------------------------------------------------------------

	m_Camera.targetRot.y = modelRot.y + D3DX_PI;

	//���K���i��]�l�𐳂����l�ɕϊ��j
	if( m_Camera.targetRot.y > D3DX_PI )
	{
		m_Camera.targetRot.y = m_Camera.targetRot.y - ( D3DX_PI * 2 );
	}
	else if( m_Camera.targetRot.y < -D3DX_PI )
	{
		m_Camera.targetRot.y = m_Camera.targetRot.y + ( D3DX_PI * 2 );
	}

	//-----------------------------------------------------------------
	//���݂̃J�����̉�]�l�ƖړI�̉�]�l���Ⴄ�ꍇ
	if( m_Camera.targetRot.y != m_Camera.rot.y )
	{
		m_Camera.fDistance = m_Camera.targetRot.y - m_Camera.rot.y;

		//���K���i��]�l�𐳂����l�ɕϊ��j
		if( m_Camera.fDistance > D3DX_PI )
		{
			m_Camera.fDistance = m_Camera.fDistance - ( D3DX_PI * 2 );
		}
		else if( m_Camera.fDistance < -D3DX_PI )
		{
			m_Camera.fDistance = m_Camera.fDistance + ( D3DX_PI * 2 );
		}

		//��]���鑬�x
		m_Camera.rot.y += m_Camera.fDistance * CAMERA_ROTATION_SPEED;

			
		//���K���i��]�l�𐳂����l�ɕϊ��j
		if( m_Camera.rot.y > D3DX_PI )
		{
			m_Camera.rot.y = m_Camera.rot.y - ( D3DX_PI * 2 );
		}
		else if( m_Camera.rot.y < -D3DX_PI )
		{
			m_Camera.rot.y = m_Camera.rot.y + ( D3DX_PI * 2 );
		}
	}

	////-----------------------------------------------------------------
	////���_�ύX����

	////�����낵���_�֕ύX

	//if( Input->GetKeyboardPress( DIK_UP ) )
	//{
	//	if( Input->GetKeyboardPress( DIK_RSHIFT ) )
	//	{
	//		m_Camera.posV.x += sinf( m_Camera.rot.y ) * 2.0f;
	//		m_Camera.posV.z += cosf( m_Camera.rot.y ) * 2.0f;

	//		m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//		m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;

	//		//�T�E���h�쐬
	//		CSound_OpenAL::Stop( 1 );
	//		CSound_OpenAL::Play( 2 );
	//	}
	//	else
	//	{
	//		m_Camera.posV.x += sinf( m_Camera.rot.y ) * 3.0f;
	//		m_Camera.posV.z += cosf( m_Camera.rot.y ) * 3.0f;

	//		m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//		m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;

	//		//�T�E���h�쐬
	//		CSound_OpenAL::Play( 1 );
	//	}
	//}
	//else
	//{
	//	//�T�E���h�쐬
	//	CSound_OpenAL::Stop( 1 );
	//	CSound_OpenAL::Stop( 2 );
	//}

	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_DOWN ) )
	//{
	//	m_Camera.posV.x -= sinf( m_Camera.rot.y ) * 5.0f;
	//	m_Camera.posV.z -= cosf( m_Camera.rot.y ) * 5.0f;

	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;

	//}
	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_LEFT ) )
	//{
	//	m_Camera.rot.y -= 0.1f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;

	//}
	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_RIGHT ) )
	//{
	//	m_Camera.rot.y += 0.1f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;

	//}

	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_Q ) )
	//{
	//	m_Camera.posV.y += 3;

	//	m_Camera.posR.y += 3;
	//}

	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_E ) )
	//{
	//	m_Camera.posV.y-=3;

	//	m_Camera.posR.y-=3;
	//}
	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_R ) )
	//{
	//	m_Camera.posR.y +=3;

	//}
	////�����낵���_�֕ύX
	//if( Input->GetKeyboardPress( DIK_F ) )
	//{
	//	m_Camera.posR.y-=3;

	//}

	//// ---�}�E�X�{�^������---
	//if( Input->GetMouseRgbButtons( 0 ) )
	//{
	//	m_Camera.rot.y -= 0.1f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;
	//}
	//if( Input->GetMouseRgbButtons( 1 ) )
	//{
	//	m_Camera.rot.y += 0.1f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;
	//}

	//// ---�}�E�X����---
	//if( Input->GetMouseUp() )
	//{
	//	m_Camera.posR.y -=15;
	//}
	//if( Input->GetMouseDown() )
	//{
	//	m_Camera.posR.y +=15;
	//}

	//if( Input->GetMouseRight() )
	//{
	//	m_Camera.rot.y += 0.08f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;
	//}
	//if( Input->GetMouseLeft() )
	//{
	//	m_Camera.rot.y -= 0.08f;
	//	m_Camera.posR.x = m_Camera.posV.x + sinf( m_Camera.rot.y ) * m_Camera.fDistance;
	//	m_Camera.posR.z = m_Camera.posV.z + cosf( m_Camera.rot.y ) * m_Camera.fDistance;
	//}

}

//-----------------------------------------------------------------
//�`�揈��
//-----------------------------------------------------------------
void CCamera::Draw( void )
{
	CManager *maneger = GetManager();

	//�N���X�̃R�s�[
	CRenderer *rendererCamera;

	rendererCamera = maneger->GetRenderer();

	m_D3DDevice = rendererCamera->GetDevice();

	//�v���W�F�N�g�}�b�s���O�̏�����
	D3DXMatrixIdentity( &m_Camera.mtxProjection );

	//�v���W�F�N�V�����}�b�s���O�̍쐬
	D3DXMatrixPerspectiveFovLH( &m_Camera.mtxProjection ,
								D3DX_PI / 2 ,//����p
								SCREEN_WIDTH/SCREEN_HEIGHT ,//�����_�ł̌v�Z
								0.1f ,
								10000.0f );

	//�v���W�F�N�V�����}�g���b�N�X�̍쐬
	m_D3DDevice->SetTransform( D3DTS_PROJECTION ,
							&m_Camera.mtxProjection );

	//�r���[�}�g���b�N�X������
	D3DXMatrixIdentity( &m_Camera.mtxView );

	//�r���[�}�g���b�N�X�쐬
	D3DXMatrixLookAtLH( &m_Camera.mtxView ,
						&m_Camera.posV ,
						&m_Camera.posR ,
						&m_Camera.VecU );

	m_D3DDevice->SetTransform( D3DTS_VIEW , &m_Camera.mtxView );
}

//-----------------------------------------------------------------
//�J�����̈ʒu�����擾����֐�
//-----------------------------------------------------------------
D3DXVECTOR3 CCamera::GetRotation ( D3DXVECTOR3 rot )
{
	rot = m_Camera.rot;

	return rot;
}

//-----------------------------------------------------------------
//�J�����̐ݒ�
//-----------------------------------------------------------------
void CCamera::SetCamera ( float x , float y , float z )
{
	z = m_Camera.posV.z;
}