/*-----------------------------------------------------------------*/
/*制作者：玉越大雄
/*制作日：2020/1.13
/*参考資料：https://mukuchi.work/fadeconts/
/*メモ
/*画面内に要素が確認できた場合、fade処理を行うjs
/*使い方：クラス名にfadeと記載すること*/
/*-----------------------------------------------------------------*/

var fade = document.querySelectorAll(".fade");
var fadeRect = [];
var fadeTop = [];
var windowY = window.pageYOffset; //ウィンドウのY座標
var windowH = window.innerHeight; //ウィンドウの高さ
var remainder = 500; //はみ出る部分

/*要素の座標を取得
--------------------------------*/
for(var i = 0 ; i < fade.length ; i++)
{
  fade[i].style.opacity = "0";
  fade[i].style.transition = "all 1s";
  fadeRect.push(fade[i].getBoundingClientRect()); //ビューポート取得
}
for(var i = 0 ; i < fadeRect.length ; i++)
{
  fadeTop.push(fadeRect[i].top + windowY);
}
for(var i = 0 ; i < fade.length ; i++)
{
  if(windowY > fadeTop[i] - windowH + remainder)
  {
    fade[i].style.opacity = "1";
  }else{
    //fade[i].classList.remove(".show");
  }
}

console.log(fade[0]);

/*ウィンドウがリサイズされた場合、ウィンドウの高さを再取得
--------------------------------*/
window.addEventListener("resize",function(){
  windowH = window.innerHeight;
  console.log(windowH);
});

/*スクロールした場合の処理
--------------------------------*/
window.addEventListener("scroll",function(){
  windowY = window.pageYOffset;

  for(var i = 0 ; i < fade.length ; i++)
  {
    if(windowY > fadeTop[i] - windowH + remainder)
    {
      fade[i].style.opacity = "1";
    }else{
      //fade[i].classList.remove(".show");
    }
  }
});