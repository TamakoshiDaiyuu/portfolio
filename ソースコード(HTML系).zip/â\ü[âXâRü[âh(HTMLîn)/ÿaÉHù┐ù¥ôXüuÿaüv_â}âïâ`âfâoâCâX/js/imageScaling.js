/*-----------------------------------------------------------------*/
/*制作者：玉越大雄
/*制作日：2020/1.13

/*メモ
/*ライトボックスの画像選択時拡大縮小機能。*/
/*for in 文内で文字列が配列内に潜り込んでいたので、数値のみ処理を行う指定をする*/
/*使い方：クラス名にlightBoxと記載すること*/
/*-----------------------------------------------------------------*/

var imageScaling = document.querySelectorAll(".imageScaling");

for(var i = 0 ; i < imageScaling.length ; i++)
{
  imageScaling[i].style.transition = "all 0.5s";
  imageScaling[i].style.transform = "scale(0.8)"
}

for(var key in imageScaling){
  (function(key_){

    if(key_ < imageScaling.length)
    {
      console.log(1);
      imageScaling[key_].addEventListener("mouseover",ZoomIn , false);
      function ZoomIn(){
        imageScaling[key_].style.transform = "scale(1)";
      }

      imageScaling[key_].addEventListener("mouseout",ZoomOut);
      function ZoomOut(){
        imageScaling[key_].style.transform = "scale(0.8)";
      }
    }
   }(key));
}